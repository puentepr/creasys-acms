﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionJoinGSelect
{
    class Program
    {
        static void Main(string[] args)
        {
            Program qeJoin = new Program();
            qeJoin.SetJoin();
            Console.ReadKey();
        }
        class Books
        {
            public string BookTitle { get; set; }
            public int BookCategoryID { get; set; }
        }
        class BooksCat
        {
            public string CategoryName { get; set; }
            public int CategoryID { get; set; }
        }
        private void SetJoin()
        {
            var joinQuery =
                from booksCategory in booksCatList
                join book in booksList on
                booksCategory.CategoryID equals book.BookCategoryID
                into bookGroup
                select new
                {
                    bCategory = booksCategory.CategoryName,
                    bTitle = from bTitle in bookGroup select bTitle 
                } ;

            foreach (var items in joinQuery)
            {
                Console.WriteLine(items.bCategory);
                foreach (var item in items.bTitle )
                    {
                        Console.WriteLine( " > "+item.BookTitle);
                    }
                    Console.WriteLine("=============================");
                
            }
            Console.ReadKey();
        }
        //書籍分類
        List<BooksCat> booksCatList = new List<BooksCat>()
        { 
            new BooksCat()
            {CategoryName="3D動畫", CategoryID=001},
            new BooksCat()
            {CategoryName="資料庫", CategoryID=002},
            new BooksCat()
            {CategoryName="影像繪圖", CategoryID=003},
            new BooksCat()
            {CategoryName="作業系統與伺服器", CategoryID=004},
            new BooksCat()
            {CategoryName="程式開發", CategoryID=005} ,       
            new BooksCat()
            {CategoryName="網頁設計", CategoryID=006}  ,
            new BooksCat()
            {CategoryName="網頁開發", CategoryID=007},
            new BooksCat()
            {CategoryName="自由軟體", CategoryID=008}
        };
        //書籍資料
        List<Books> booksList = new List<Books>()
        { 
            new Books()
            {BookTitle="MAYA 火星講堂", BookCategoryID=001},
            new Books()
            {BookTitle="3ds Max 9 動畫奧義", BookCategoryID=001},
            new Books()
            {BookTitle="Microsoft SQL Server 2005設計商業智慧解決方案", BookCategoryID=002},
            new Books()
            {BookTitle="SQL Server 2005 Performance Tuning效能調校", BookCategoryID=002},
            new Books()
            {BookTitle="Microsoft SQL Server 2005最佳化和維護資料庫系統管理員解決方案", BookCategoryID=002},    
            new Books()
            {BookTitle="SQL Server 2005 T-SQL資料庫設計", BookCategoryID=002},
            new Books()
            {BookTitle="使用Microsoft.NET Framework設計及開發Web應用程式", BookCategoryID=005},
            new Books()
            {BookTitle="Windows Communication Foundation 新一代應用程式通訊架構", BookCategoryID=005},
            new Books()
            {BookTitle="Professional Ajax", BookCategoryID=005},    
            new Books()
            {BookTitle="Microsoft .NET Framework 2.0 應用程式開發基礎", BookCategoryID=005},
            new Books()
            {BookTitle="Windows Workflow Foundation 新一代工作流程開發實務", BookCategoryID=005},
            new Books()
            {BookTitle="Flash CS3 Professional ActionScript 3.0 打造互動網頁力與美", BookCategoryID=006},
            new Books()
            {BookTitle="Dreamweaver CS3 網頁設計驚嘆號 至高的網頁特效172．招", BookCategoryID=006},
            new Books()
            {BookTitle="Photoshop CS3 影像創造力╳基礎講堂", BookCategoryID=003},
            new Books()
            {BookTitle="手繪魅力100%Photoshop+Wacom", BookCategoryID=003},
            new Books()
            {BookTitle="Red Hat Enterprise Linux 5 系統管理寶典-基礎篇", BookCategoryID=004},
            new Books()
            {BookTitle="Linux作業系統之奧義", BookCategoryID=004},    
            new Books()
            {BookTitle="Microsoft Office SharePoint Server 2007 新一代企業表單與內容管理 |第2集|", BookCategoryID=004},
            new Books()
            {BookTitle="Windows Vista系統管理的實戰主義", BookCategoryID=004},
            new Books()
            {BookTitle="Silverlight：ASP.NET與AJAX開發實務", BookCategoryID=007}, 
            new Books()
            {BookTitle="ASP.NET 2.0 網站開發學習講座", BookCategoryID=007},
            new Books()
            {BookTitle="LINQ入門精義剖析", BookCategoryID=999},
            new Books()
            {BookTitle="ASP.NET 2.0 網站開發學習講座", BookCategoryID=007}

        };
    }
}
