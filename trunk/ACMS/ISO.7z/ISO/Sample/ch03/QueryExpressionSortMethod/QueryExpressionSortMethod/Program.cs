﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSortMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> strList =
                new List<string> { "Mod", "Tue", "Wed", "Thu", "Fri", "Sat", "SUN" };

            IEnumerable<string> enumList =
                from str in strList
                orderby str.Substring(0,3)
                select str;

            //IEnumerable<string> enumList =
            //    strList.OrderBy(str => str.Substring(2, 1)); 


            string orderbyString = "原始字串：";
            foreach (string str in strList)
            {
                orderbyString += str + ",";
            }
            Console.WriteLine(orderbyString);
            orderbyString = "排序後的字串："; 
            foreach (string str in enumList)
            {
                orderbyString += str + ","; 
            }
            Console.WriteLine(orderbyString);
            Console.ReadLine(); 
        }
    }
}
