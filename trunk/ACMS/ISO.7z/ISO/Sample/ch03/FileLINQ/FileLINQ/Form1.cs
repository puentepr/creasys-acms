﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO   ; 

namespace FileLINQ
{
    public partial class Form1 : Form
    {
        IEnumerable<FileInfo> enumFileinfos = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void PathButton_Click(object sender, EventArgs e)
        {
            DialogResult dr = LINQFolderBrowserDialog.ShowDialog();
            if (dr == DialogResult.OK)
                FileTextBox.Text = LINQFolderBrowserDialog.SelectedPath; ;

            enumFileinfos = GetFiles(FileTextBox.Text);                     
        }
        public  IEnumerable<FileInfo > GetFiles(string filePath)
        {
            try{
                IEnumerable<FileInfo> enumFileinfos = null;
                if (Directory.Exists(filePath) == false)
                {
                    throw new DirectoryNotFoundException()    ; 
                }
                List<FileInfo> fileList = new List<FileInfo>();
                string[] files = Directory.GetFiles(filePath);
                foreach (string fileName in files)
                {
                    FileInfo fi = new FileInfo(fileName);
                    fileList.Add(fi);
                }
                enumFileinfos = fileList;
                return enumFileinfos ;
            }
            catch (DirectoryNotFoundException enfe )
            {
                MessageBox.Show(enfe.Message );
                return null; 
            }
        }

        private void RFileButton_Click(object sender, EventArgs e)
        {
            if (enumFileinfos == null)
            {
                MessageBox.Show("指定解析路徑 !! ");
                return;
            }

            Func<FileInfo, object > fd = null    ;

            if( CTRadioButton.Checked )
                fd = x => x.CreationTime ;

            if(FileNameRadioButton.Checked )
                fd = x => x.Name    ;
           
            if(FNLengthRadioButton.Checked )
                fd = x => x.Name.Length ;

            IEnumerable<FileInfo> enumFileinfosearch =
                from file in enumFileinfos
                orderby fd(file)   
                where file.Name.Contains(ConditionTextBox.Text)   
                select file  ;


            string fileNames = "";
            foreach (FileInfo sFile in enumFileinfosearch)
            {
                fileNames += 
                    sFile.CreationTime.ToString("yyy/MM/dd")+ "　" + 
                    sFile.FullName  + "\n";
            }
            FileRichTextBox.Text = fileNames; 
        }

    }
}
