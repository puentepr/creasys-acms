﻿namespace FileLINQ
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.FileTextBox = new System.Windows.Forms.TextBox();
            this.PathButton = new System.Windows.Forms.Button();
            this.LINQFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.FileRichTextBox = new System.Windows.Forms.RichTextBox();
            this.RFileButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CTRadioButton = new System.Windows.Forms.RadioButton();
            this.ConditionTextBox = new System.Windows.Forms.TextBox();
            this.FileNameRadioButton = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.FNLengthRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(40, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "檔案路徑";
            // 
            // FileTextBox
            // 
            this.FileTextBox.Location = new System.Drawing.Point(118, 11);
            this.FileTextBox.Name = "FileTextBox";
            this.FileTextBox.Size = new System.Drawing.Size(373, 22);
            this.FileTextBox.TabIndex = 1;
            // 
            // PathButton
            // 
            this.PathButton.Location = new System.Drawing.Point(498, 9);
            this.PathButton.Name = "PathButton";
            this.PathButton.Size = new System.Drawing.Size(97, 23);
            this.PathButton.TabIndex = 2;
            this.PathButton.Text = "指定檔案路徑";
            this.PathButton.UseVisualStyleBackColor = true;
            this.PathButton.Click += new System.EventHandler(this.PathButton_Click);
            // 
            // FileRichTextBox
            // 
            this.FileRichTextBox.Location = new System.Drawing.Point(118, 91);
            this.FileRichTextBox.Name = "FileRichTextBox";
            this.FileRichTextBox.Size = new System.Drawing.Size(594, 235);
            this.FileRichTextBox.TabIndex = 3;
            this.FileRichTextBox.Text = "";
            // 
            // RFileButton
            // 
            this.RFileButton.Location = new System.Drawing.Point(601, 8);
            this.RFileButton.Name = "RFileButton";
            this.RFileButton.Size = new System.Drawing.Size(111, 23);
            this.RFileButton.TabIndex = 4;
            this.RFileButton.Text = "解析資料夾";
            this.RFileButton.UseVisualStyleBackColor = true;
            this.RFileButton.Click += new System.EventHandler(this.RFileButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.FNLengthRadioButton);
            this.groupBox1.Controls.Add(this.FileNameRadioButton);
            this.groupBox1.Controls.Add(this.CTRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(291, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 45);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "排序";
            // 
            // CTRadioButton
            // 
            this.CTRadioButton.AutoSize = true;
            this.CTRadioButton.Checked = true;
            this.CTRadioButton.Location = new System.Drawing.Point(23, 21);
            this.CTRadioButton.Name = "CTRadioButton";
            this.CTRadioButton.Size = new System.Drawing.Size(71, 16);
            this.CTRadioButton.TabIndex = 0;
            this.CTRadioButton.TabStop = true;
            this.CTRadioButton.Text = "建立時間";
            this.CTRadioButton.UseVisualStyleBackColor = true;
            // 
            // ConditionTextBox
            // 
            this.ConditionTextBox.Location = new System.Drawing.Point(118, 54);
            this.ConditionTextBox.Name = "ConditionTextBox";
            this.ConditionTextBox.Size = new System.Drawing.Size(121, 22);
            this.ConditionTextBox.TabIndex = 6;
            // 
            // FileNameRadioButton
            // 
            this.FileNameRadioButton.AutoSize = true;
            this.FileNameRadioButton.Location = new System.Drawing.Point(129, 20);
            this.FileNameRadioButton.Name = "FileNameRadioButton";
            this.FileNameRadioButton.Size = new System.Drawing.Size(71, 16);
            this.FileNameRadioButton.TabIndex = 1;
            this.FileNameRadioButton.TabStop = true;
            this.FileNameRadioButton.Text = "檔案名稱";
            this.FileNameRadioButton.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(8, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "篩選檔案名稱";
            // 
            // FNLengthRadioButton
            // 
            this.FNLengthRadioButton.AutoSize = true;
            this.FNLengthRadioButton.Location = new System.Drawing.Point(242, 20);
            this.FNLengthRadioButton.Name = "FNLengthRadioButton";
            this.FNLengthRadioButton.Size = new System.Drawing.Size(95, 16);
            this.FNLengthRadioButton.TabIndex = 2;
            this.FNLengthRadioButton.TabStop = true;
            this.FNLengthRadioButton.Text = "檔案名稱長度";
            this.FNLengthRadioButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 345);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ConditionTextBox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.RFileButton);
            this.Controls.Add(this.FileRichTextBox);
            this.Controls.Add(this.PathButton);
            this.Controls.Add(this.FileTextBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FileTextBox;
        private System.Windows.Forms.Button PathButton;
        private System.Windows.Forms.FolderBrowserDialog LINQFolderBrowserDialog;
        private System.Windows.Forms.RichTextBox FileRichTextBox;
        private System.Windows.Forms.Button RFileButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton CTRadioButton;
        private System.Windows.Forms.TextBox ConditionTextBox;
        private System.Windows.Forms.RadioButton FileNameRadioButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton FNLengthRadioButton;
    }
}

