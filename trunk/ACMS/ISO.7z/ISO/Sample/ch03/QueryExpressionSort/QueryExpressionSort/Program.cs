﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSort
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] foxdog = { 
                "the quick brown fox jumps over the lazy dog"};
            IEnumerable<char> enumfoxdog =
                from words in foxdog
                from fd in words
                where fd != ' '
                orderby fd descending 
                select fd ;

            string foxdogString = "原始字串:\n";
            foreach (string word in foxdog)
            {
                foxdogString += word + "\n";
            }
            Console.WriteLine(foxdogString);

            foxdogString = "排序後的字母:";
            foreach (char d in enumfoxdog)
            {
                foxdogString += d  ;
            }
            Console.WriteLine(foxdogString);

            Console.ReadLine();

        }
    }
}
