﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSelect
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] weekDays = { 
                "MONDAY","TUESDAY","Wednesday",
                "Thursday","Friday","SATURDAY","SUNDAY"};
            IEnumerable<string> enumWeekDays =
                from weekDay in weekDays
                select weekDay.Substring(0,3) ;

            string weekDayOutput = "一星期七天的英文全名:";
            foreach (string day in weekDays)
            {
                weekDayOutput += day + ",";
            }
            Console.WriteLine(weekDayOutput);
            weekDayOutput = "一星期七天的英文全名縮寫:";
            foreach (string day in enumWeekDays)
            {
                weekDayOutput += day + ",";
            }
            Console.WriteLine(weekDayOutput);

            Console.ReadLine();

        }
    }
}