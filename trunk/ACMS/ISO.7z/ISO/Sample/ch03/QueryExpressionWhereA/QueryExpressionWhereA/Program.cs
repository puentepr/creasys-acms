﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionWhereA
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numberQuery = { 
                123,456,789,100,365,7,24 };
            IEnumerable<int> enumNumbers =
                from number in numberQuery
                where number <= 300 && number>=100
                select number;

            string source = "原始數字:";
            foreach (int number in numberQuery)
            {
                source += number + ",";
            }
            Console.WriteLine(source);

            string result = "搜尋結果(100-300間的數字):";

            foreach (int number in enumNumbers)
            {
                result += number + ",";
            }
            Console.WriteLine(result);

            enumNumbers =
                from number in numberQuery
                where CheckEven(number) 
                select number;

            result = "搜尋結果(偶數):";
            foreach (int number in enumNumbers)
            {
                result += number + ",";
            }
            Console.WriteLine(result);

            Console.ReadLine(); 

        }
        private static bool CheckEven(int nvalue)
        {
            bool returnValue = (nvalue % 2 == 0);
            return returnValue; 

        }
    }
}
