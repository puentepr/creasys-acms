﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSortS
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] weekDays = { 
                "Monday","Tuesday","Wednesday",
                "Thursday","Friday","Saturday","Sunday"};
            IEnumerable<string> enumWeekDays =
                from weekDay in weekDays
                orderby weekDay.Length,weekDay.Substring(0,1) 
                select weekDay;

            string weekDayOutput = "一星期七天的英文全名:";
            foreach (string day in weekDays)
            {
                weekDayOutput += day + ",";
            }
            Console.WriteLine(weekDayOutput);
            weekDayOutput = "一星期七天的英文全名(排序):";
            foreach (string day in enumWeekDays)
            {
                weekDayOutput += day + ",";
            }
            Console.WriteLine(weekDayOutput);

            Console.ReadLine();

        }
    }
}
