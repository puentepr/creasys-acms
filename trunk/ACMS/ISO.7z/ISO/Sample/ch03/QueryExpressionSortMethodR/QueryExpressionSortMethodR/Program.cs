﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSortMethodR
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> strList =
        new List<string> { "Mod", "Tue", "Wed", "Thu", "Fri", "Sat", "SUN" };

            IEnumerable<string> enumList =
                from str in strList
                orderby str.Substring(0, 3)
                select str;

            string orderbyString = "原始字串：";
            foreach (string str in strList)
            {
                orderbyString += str + ",";
            }
            Console.WriteLine(orderbyString);
            orderbyString = "排序後的字串：";
            foreach (string str in enumList)
            {
                orderbyString += str + ",";
            }
            Console.WriteLine(orderbyString);

            enumList = enumList.Reverse();

            orderbyString = "反轉後的字串：";
            foreach (string str in enumList)
            {
                orderbyString += str + ",";
            }
            Console.WriteLine(orderbyString);
            Console.ReadLine(); 
        }
    }
}
