﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionAllEmpty
{
    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<String> enumerable = Enumerable.Empty<string>();
            bool anyBool = enumerable.Any();
            if (anyBool == false)
                Console.WriteLine("enumerable集合內容是 空值…"); 
            else
                Console.WriteLine("enumerable集合內容非 空值…");           
            
            Console.ReadKey();
        }
    }
}
