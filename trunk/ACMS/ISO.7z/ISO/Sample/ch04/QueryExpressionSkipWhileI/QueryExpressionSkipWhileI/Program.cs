﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSkipWhileI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> intList =
                new List<int> { 1, 2, 3, 4, -5 , 6, 7, 8, 9, 0 };

            IEnumerable<int> intListSkip =
                intList.SkipWhile((iNumber,index) => iNumber > index );

            Console.WriteLine("原始集合內容:");
            foreach (int i in intList)
                Console.Write(i + ",");

            Console.WriteLine("\nSkip 之後的集合內容:");
            foreach (int i in intListSkip)
                Console.Write(i + ",");
            Console.Read();
        }
    }
}
