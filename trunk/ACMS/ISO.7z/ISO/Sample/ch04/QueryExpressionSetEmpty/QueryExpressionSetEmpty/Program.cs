﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSetEmpty
{
    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<string> enumerable = Enumerable.Empty<string >();
            int result = 0; 
            foreach (var str in enumerable)
            {
                result++; 
            }
            Console.WriteLine("enumerable內容元素數目："+result.ToString()  )  ;
            Console.ReadKey();  
        }
    }
}
