﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections; 

namespace QueryExpressCast
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList(); 
            al.Add("Monday")  ;
            al.Add("Tuesday")  ;
            al.Add("Wednesday")  ;
            al.Add("Thursday")  ;
            al.Add("Friday")  ;
            al.Add("Saturday")  ;
            al.Add("Sunday")  ;

            IEnumerable<string> enumObject = al.Cast<String>();
            IEnumerable ie = enumObject.Select(
                obj => obj.Substring(0, 3).ToUpper() );
            foreach (string str in ie)
                Console.WriteLine(str);

            Console.ReadKey();
           
        }
    }
}
