﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSetRepeat
{
    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<string> enumerable = 
                Enumerable.Repeat<string>("www.kangting.tw",5);
           
            foreach (var str in enumerable)
            {
                Console.WriteLine(str);  
            }
            Console.ReadKey()  ; 
        }
    }
}
