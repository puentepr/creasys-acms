﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressToToDictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Books> booksList = new List<Books>
            {
                new Books{BookTitle =
                    "手繪魅力100%Photoshop+Wacom" , BookIAuthor="麻理鈴" , 
                    BookISBN="978-986-6761-17-1" ,BookKD = "001"},
                new Books{BookTitle =
                    "Silverlight：ASP.NET與AJAX開發實務",BookIAuthor="呂高旭" , 
                    BookISBN="978-986-6761-12-6",BookKD = "002" },
                new Books{BookTitle =
                    "ASP.NET 2.0 網站開發學習講座" , BookIAuthor="鄭淑芬" , 
                    BookISBN="978-986-82779-0-8",BookKD = "003" },
                new Books{BookTitle =
                    "Professional Ajax" , BookIAuthor="戴玉佩 " , 
                    BookISBN="978-986-6761-16-4",BookKD = "004"  },
                new Books{BookTitle =
                    "Linux作業系統之奧義" , BookIAuthor="邱世華 " , 
                    BookISBN="978-986-6761-06-5",BookKD = "005" }
            };           
            Dictionary<string , Books> bookDictionary =
                booksList.ToDictionary(
                key => key.BookKD + "-" + key.BookISBN );

            foreach (KeyValuePair<string, Books> kvp in bookDictionary)
            {
                Console.WriteLine(
                    "ID："+kvp.Key + ","+
                    "書名："+kvp.Value.BookTitle + ","+
                    "作者："+kvp.Value.BookIAuthor );
            }
            Console.ReadKey(); 
        }
        class Books
        {
            public string BookTitle { get; set; } 
            public string BookISBN{get; set; }
            public string BookIAuthor { get; set; }
            public string BookKD { get; set; }
        }
    }
}
