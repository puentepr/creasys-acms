﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionContain
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> stringList = 
                new List<string> { 
                    "Mon", "Tue", "Wed", "Thu",
                    "Fri","Sat","Sun"};

            IEnumerable<string> enumWeekDay =
                from day in stringList
                where day.Substring(0, 1) == "S"
                select day;

            bool containBool  = enumWeekDay.Contains("Sun");
            if (containBool == true)
            {
                Console.WriteLine("一星期中，以S開頭的名稱：");
                foreach (string str in enumWeekDay)
                    Console.WriteLine(str); 
            }
            Console.ReadKey();                
        }
    }
}
