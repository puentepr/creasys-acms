﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionAsEnum
{
    class Program
    {
        static void Main(string[] args)
        {
            NumberAgg<int> na = new NumberAgg<int>
            {
                1,2,3,4,5,6,7,8,9,10           
            };
            string strOut = "";
            Console.WriteLine(
                "--NumberAgg 集合內容--");
            foreach (int value  in na)
            {
                strOut += value.ToString() + ","; 
                
            }
            Console.WriteLine(strOut);
        
            double average = na.Average();
            Console.WriteLine(average.ToString());    
        
            IEnumerable<int> i = na.AsEnumerable<int>();
            average  = i.Average()  ;
            Console.WriteLine(
                "--原始版本的 Average 方法--");
            Console.WriteLine(average.ToString());

            Console.ReadLine();
        }
    }
    public   class NumberAgg<T> :List<T>
    {
        public double  Average()
        {
            Console.WriteLine(
                "--NumberAgg覆寫的 Average 方法--");
            return 100;  
        }

    }
   
}
