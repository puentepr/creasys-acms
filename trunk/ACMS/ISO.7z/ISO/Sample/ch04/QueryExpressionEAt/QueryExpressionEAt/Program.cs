﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionEAt
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string > weekDays =
               new List<string> { "Mon","Tue","Wed","Thu","Fri","Sat","Sun" };
            string  elementAt = weekDays.ElementAt(4);
            Console.WriteLine(
                "第五個元素值（ElementAt(4)）：" + elementAt);
            Console.ReadKey();
        }
    }
}
