﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionAll
{
    class Program
    {
        static void Main(string[] args)
        {
            List<kangting> strList =
                new List<kangting> { 
                    new kangting{website="www.kangting.tw",name="康廷數位"},
                    new kangting{website="www.kangting.tw",name="康廷"},
                    new kangting{website="www.kangting.tw",name="康廷數位工坊"}                     
                };

            bool allCheck = strList.All(kangting =>
                kangting.name == "康廷");
            if (allCheck)
                Console.WriteLine("所有的「www.kangting.tw」對應的中文名稱均是「康廷」"); 
            else
                Console.WriteLine("並非所有的「www.kangting.tw」對應的中文名稱均是「康廷」");


            List<checkString> strList2 = new List<checkString> { 
                new checkString{qName="www"},
                new checkString{qName="www.kangting"},
                new checkString{qName="www.kangting.tw"},
            };
            allCheck = strList2.All(checkString =>
                            checkString.qName.StartsWith("www"));
            if (allCheck)
                Console.WriteLine("所有的元素均以「www」為字首");
            else
                Console.WriteLine("並非所有均以「www」為字首");


            Console.ReadKey();
        }
        class kangting
        {
            public string website { get; set; }
            public string name  { get; set; }
        }
        class checkString
        {
            public string qName { get; set; }
        }
    }
}
