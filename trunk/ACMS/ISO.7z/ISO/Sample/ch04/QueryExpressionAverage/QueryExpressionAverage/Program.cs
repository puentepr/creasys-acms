﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionAverage
{
    class Program
    {
        static void Main(string[] args)
        {
            //List<int> list = new List<int>
            //{
            //    1,2,3,4,5,6,7,8,9,10  
            //};


            List<double?> list = new List<double?>
            {
                null,1.1,2.2,3.3,4.4,5.5,6.6,7.7,8.8,9.9,10  
            };


            double? averageValue  =   list.Average()   ;
            string str = ""; 
            Console.WriteLine("List集合內容：")  ; 
            
            foreach(double? i in list)
            {
                str+=i.ToString()+","; 
            }
            Console.WriteLine(str+"\n");

            Console.WriteLine("平均值：" + averageValue.ToString() ); 

            Console.ReadKey(); 
            
        }
    }
}