﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionDIE
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] weekDays = { 
                "Monday","Tuesday","Wednesday",
                "Thursday","Friday","Saturday","Sunday"};

            IEnumerable<string> enumObject = weekDays.DefaultIfEmpty();

            Console.WriteLine("weekDays字串陣列內容：");
            foreach (string day in weekDays)
                Console.Write(day + ",");
            Console.WriteLine("\n引用 DefaultIfEmpty 回傳的結果：");
            foreach (string day in enumObject)
                Console.Write( day + ",");

            Console.WriteLine("\n空集合引用 DefaultIfEmpty 回傳的結果：");

            IEnumerable<string> enumEmpty = Enumerable.Empty<string>();
            enumEmpty = enumEmpty.DefaultIfEmpty("SUNDAY");
            foreach (string day in enumEmpty)
                Console.Write(day + ",");            
            Console.ReadKey(); 

        }
    }
}
