﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSingleD
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> weekDays =
                new List<string> { "www.kangting.tw" };
            foreach (string str in weekDays)
            {
                Console.WriteLine(
                "原始字串：" + str);
            }

            string elementSingle = 
                weekDays.SingleOrDefault(
                str=>str.Substring(4,8)=="kangting");
            Console.WriteLine(
                "元素的第五個字開始的八個字等於 kangting：" + elementSingle);

            elementSingle =
                weekDays.SingleOrDefault(
                str => str.Substring(0, 3) == "wwk");
            Console.WriteLine(
                "元素的第一個字開始的三個字等於 www：" + elementSingle);

            Console.ReadKey();
        }
    }
}
