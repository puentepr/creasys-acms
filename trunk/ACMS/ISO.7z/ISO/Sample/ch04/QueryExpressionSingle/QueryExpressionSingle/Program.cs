﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSingle
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> weekDays =
                new List<string> {"www.kangting.tw" };
            string elementSingle = weekDays.Single();
            Console.WriteLine(elementSingle);
            Console.ReadKey();

        }
    }
}
