﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionListArrayC
{
    class Program
    {
        static void Main(string[] args)
        {
            List<WeekDays> listWeekDay = new List<WeekDays>
            {
                new WeekDays{ DayName="Mon",FullDayName="Monday"},
                new WeekDays{ DayName="Tue",FullDayName="Tuesday"},
                new WeekDays{ DayName="Wed",FullDayName="Wednesday"},
                new WeekDays{ DayName="Thu",FullDayName="Thursday"},
                new WeekDays{ DayName="Fri",FullDayName="Friday"},
                new WeekDays{ DayName="Sat",FullDayName="Saturday"},
               
                new WeekDays{ DayName="Sun",FullDayName="Sunday"},
            };
            string[] arrayWeekDay = 
                listWeekDay.Select(weekday => weekday.FullDayName).ToArray();
            foreach (string str in arrayWeekDay)
            {
                Console.Write(str + ","); 
            }
            Console.Read();
        }        
    }
    class WeekDays
    {
        public string DayName { get; set; }
        public string FullDayName { get; set; }
    }
}
