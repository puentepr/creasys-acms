﻿namespace QueryExpressionAverageMethod
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.NumberTextBox = new System.Windows.Forms.TextBox();
            this.AggButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ResultRichTextBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // NumberTextBox
            // 
            this.NumberTextBox.Location = new System.Drawing.Point(26, 37);
            this.NumberTextBox.Name = "NumberTextBox";
            this.NumberTextBox.Size = new System.Drawing.Size(508, 22);
            this.NumberTextBox.TabIndex = 0;
            // 
            // AggButton
            // 
            this.AggButton.Location = new System.Drawing.Point(430, 66);
            this.AggButton.Name = "AggButton";
            this.AggButton.Size = new System.Drawing.Size(85, 23);
            this.AggButton.TabIndex = 1;
            this.AggButton.Text = "彙總運算";
            this.AggButton.UseVisualStyleBackColor = true;
            this.AggButton.Click += new System.EventHandler(this.AggButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(23, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "請以逗號分隔輸入運算數值（例如：1,2,3,4,5,6... ）";
            // 
            // ResultRichTextBox
            // 
            this.ResultRichTextBox.Location = new System.Drawing.Point(26, 66);
            this.ResultRichTextBox.Name = "ResultRichTextBox";
            this.ResultRichTextBox.Size = new System.Drawing.Size(375, 174);
            this.ResultRichTextBox.TabIndex = 3;
            this.ResultRichTextBox.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 252);
            this.Controls.Add(this.ResultRichTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AggButton);
            this.Controls.Add(this.NumberTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NumberTextBox;
        private System.Windows.Forms.Button AggButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox ResultRichTextBox;
    }
}

