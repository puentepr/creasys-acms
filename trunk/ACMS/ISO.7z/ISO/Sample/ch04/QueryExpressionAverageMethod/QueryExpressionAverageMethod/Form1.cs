﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QueryExpressionAverageMethod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void AggButton_Click(object sender, EventArgs e)
        {
            try
            {
                string[] strs = NumberTextBox.Text.Split(',');
                IEnumerable<double> enumDbl =
                    from str in strs
                    select double.Parse(str);
                double average = enumDbl.Average();
                double max = enumDbl.Max();
                double min = enumDbl.Min();
                double sum = enumDbl.Sum();
                double count = enumDbl.Count();

                string outString =
                    "平均值：　" + average + "\n" +
                    "最大值：　" + max + "\n" +
                    "最小值：　" + min + "\n" +
                    "總　合：　" + sum + "\n" +
                    "數　目：　" + count + "\n";

                ResultRichTextBox.Text = outString;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message)    ;
            }

        }
    }
}
