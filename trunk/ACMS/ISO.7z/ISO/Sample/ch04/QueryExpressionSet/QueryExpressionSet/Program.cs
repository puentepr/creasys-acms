﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSet
{
    class Program
    {
        static void Main(string[] args)
        {

            Program program = new Program();

            char[] enumList1 =  { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', };
            char[] enumList2 =  { 'e', 'f', 'g', 'h', 'i','j','k','l','m'};

            Console.WriteLine("原始資料");
            program.ShowOutPut("enumList1：", enumList1);
            program.ShowOutPut("enumList2：", enumList2); 
            
            IEnumerable<char> enumListSet = enumList1.Union(enumList2);
            Console.WriteLine("\nunion");
            program.ShowOutPut("enumListUnion：", enumListSet);

            enumListSet = enumList1.Except(enumList2);
            Console.WriteLine("\nExcept");
            program.ShowOutPut("enumListUnion：", enumListSet);

            enumListSet = enumList1.Intersect(enumList2);
            Console.WriteLine("\nIntersect");
            program.ShowOutPut("enumListUnion：", enumListSet);
           
            Console.ReadKey(); 
        }
        private void ShowOutPut(string preStr, IEnumerable<char> enumList)
        {
            string output =preStr   ; 
            foreach (char c in enumList)
            {
                output += c + ",";                
            }
            Console.WriteLine(output);
        }
    }
}
