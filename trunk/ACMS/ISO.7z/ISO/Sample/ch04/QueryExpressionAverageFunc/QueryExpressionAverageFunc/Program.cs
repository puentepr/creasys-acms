﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionAverageFunc
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>
            {
                "microsoft","yahoo","google","eBay",
                "amazon","msn","youtube","flickr"  
            };

            double averageValue = list.Average(str=>str.Length );
            string strList = "";
            Console.WriteLine("List集合內容：");

            foreach (string str in list)
            {
                strList += str + ",";
            }
            Console.WriteLine(strList + "\n");
            Console.WriteLine("字串長度平均值：" + averageValue.ToString());
            Console.ReadKey();
        }
    }
}
