﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressToDictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> listBooks = new List<string> 
            {
                "手繪魅力100%Photoshop+Wacom" ,
                "Silverlight：ASP.NET與AJAX開發實務"  ,
                "ASP.NET 2.0 網站開發學習講座" ,
                "Professional Ajax" ,
                "Linux作業系統之奧義"
            }; 

            int indexValue = 0   ;
            Dictionary<string, string> booksDictionary = 
                listBooks.ToDictionary(keyValue => "book_"+(indexValue++).ToString())  ;
            foreach (KeyValuePair<string, string> kvp in booksDictionary)
            {
                Console.WriteLine(
                    "ID：" + kvp.Key + ",　" +
                    "書名：" + kvp.Value );
            }
            Console.ReadKey(); 
               
        }
    }
}
