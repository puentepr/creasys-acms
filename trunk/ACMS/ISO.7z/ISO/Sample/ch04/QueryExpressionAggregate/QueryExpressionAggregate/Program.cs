﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionAggregate
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>
            {
                "microsoft","yahoo","google","eBay",
                "amazon","msn","youtube","flickr"  
            };
            string strOut = "list原始內容：\n" ;
            foreach (string str in list)
                strOut += str + ",";

            Console.WriteLine(strOut + "\n");

            //string listString =
            //    list.Aggregate(
            //    (bWord, aWord) =>
            //        bWord == "microsoft" ? "www."+bWord+".com" : bWord + 
            //        "\nwww." + aWord + ".com");



            string listString =
                list.Aggregate((bWord, aWord) => bWord + aWord + "\n");


            Console.WriteLine(
                "轉換成為完整網址列：\n"+
                listString);

            Console.ReadLine();
        }
    }
}
