﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections; 
namespace QueryExpressOfType
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList();
            al.Add("Monday");al.Add(1);
            al.Add("Tuesday");al.Add(2);
            al.Add("Wednesday");al.Add(3);
            al.Add("Thursday");al.Add(4);
            al.Add("Friday");al.Add(5);
            al.Add("Saturday");al.Add(6);
            al.Add("Sunday"); al.Add(7);

            IEnumerable<string> enumObject = al.OfType<string>();
            IEnumerable ie = enumObject.Select(
                obj => obj.Substring(0, 3).ToUpper());
            foreach (string str in ie)
                Console.WriteLine(str);

            IEnumerable<int> enumIntObject = al.OfType<int>();
            IEnumerable ieint = enumIntObject.Select(obj => obj);
            foreach (int intValue in ieint)
                Console.WriteLine(intValue);

            Console.ReadKey()  ; 
        }
    }
}
