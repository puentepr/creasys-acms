﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressToLookup
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> listBooks = new List<string> 
            {
                "手繪魅力100%Photoshop+Wacom" ,
                "Silverlight：ASP.NET與AJAX開發實務"  ,
                "ASP.NET 2.0 網站開發學習講座" ,
                "Professional Ajax" ,
                "Linux作業系統之奧義"
            };

            int indexValue = 0;
            ILookup<string, string> booksLookup =
                listBooks.ToLookup(keyValue => "book_" + indexValue.ToString());
            foreach (IGrouping<string, string> igp in booksLookup)
            {
                Console.WriteLine(
                    "ID：" + igp.Key + ",　" );
                foreach (string str in igp)
                    Console.WriteLine("　" + str);
            }
            Console.ReadKey(); 

        }
    }
}
