﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionSetEmptyDefault
{
    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<string> enumerable = Enumerable.Empty<string>();
            int result = 0;
            foreach (var str in enumerable.DefaultIfEmpty() )
            {
                result++;
            }
            Console.WriteLine("enumerable內容元素數目：" + result.ToString());
            Console.ReadKey(); 
        }
    }
}
