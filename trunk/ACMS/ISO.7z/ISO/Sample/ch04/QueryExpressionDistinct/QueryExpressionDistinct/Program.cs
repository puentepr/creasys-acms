﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionDistinct
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] foxdog = { 
                "the quick brown fox jumps over the lazy dog"};
            IEnumerable<char> enumfoxdog =
                from words in foxdog
                from fd in words
                where fd != ' '
                orderby fd 
                select fd;

            IEnumerable<char> sEnumfoxdog = enumfoxdog.Distinct();

            string foxdogString = "萃取單一字母:";
            foreach (char d in sEnumfoxdog)
            {
                foxdogString += d;
            }
            Console.WriteLine(foxdogString);

            Console.ReadKey ();

        }
    }
}
