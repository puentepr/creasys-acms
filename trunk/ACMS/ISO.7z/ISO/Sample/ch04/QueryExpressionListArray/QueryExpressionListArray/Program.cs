﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionListArray
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> weekDay =
                new List<string> {  
                    "Monday","Tuesday","Wednesday",
                    "Thursday","Friday","Saturday","Sunday" };
            string[] weekDayArray = weekDay.ToArray();
            foreach (string day in weekDayArray)
            {
                Console.Write(day + ","); 
            } 
            List<string> weekDayc = weekDayArray.ToList();
            Console.WriteLine(); 
            foreach (string day in weekDayArray)
            {
                Console.Write(day + ",");
            }
            Console.Read();
        }
    }
}
