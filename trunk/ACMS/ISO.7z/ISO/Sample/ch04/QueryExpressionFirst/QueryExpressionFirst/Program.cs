﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> intList =
                new List<int> { 1, 2, 3, 4, -5, 6, 7, 8, 9, 0 };
            int firstValue = intList.First();
            Console.WriteLine(
                "intList集合序列的第一個值："+firstValue.ToString() );
            firstValue = intList.FirstOrDefault();
            Console.WriteLine(
                "intList集合序列的第一個值：" + firstValue.ToString());

            IEnumerable<int> enumObject = Enumerable.Empty<int>()  ;
            firstValue = enumObject.FirstOrDefault();
            Console.WriteLine(
                "enumObject集合序列的第一個值（空值）：" + firstValue.ToString());
            Console.ReadKey(); 
        }
    }
}
