﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionAny
{
    class Program
    {
        static void Main(string[] args)
        {
            List<kangting> strList =
                new List<kangting> { 
                    new kangting{website="www.kangting.tw",name="康廷數位"},
                    new kangting{website="www.kangting.tw",name="康廷"},
                    new kangting{website="www.kangting.tw",name="康廷數位工坊"}                     
                };

            bool allCheck = strList.Any(kangting =>
                kangting.name == "康廷");
            if (allCheck)
                Console.WriteLine("某些「www.kangting.tw」對應的中文名稱是「康廷」");
            else
                Console.WriteLine("無任何「www.kangting.tw」對應的中文名稱是「康廷」");


            List<checkString> strList2 = new List<checkString> { 
                new checkString{qName="www"},
                new checkString{qName="www.kangting"},
                new checkString{qName="www.kangting.tw"},
            };
            allCheck = strList2.Any(checkString =>
                            checkString.qName.StartsWith("www"));
            if (allCheck)
                Console.WriteLine("某些元素以「www」為字首");
            else
                Console.WriteLine("無任何元素以「www」為字首");


            Console.ReadKey();
        }
        class kangting
        {
            public string website { get; set; }
            public string name { get; set; }
        }
        class checkString
        {
            public string qName { get; set; }
        }
    }
}
