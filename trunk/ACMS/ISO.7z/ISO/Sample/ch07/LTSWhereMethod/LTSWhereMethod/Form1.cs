﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSWhereMethod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql = "SELECT * FROM Book";
            
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql, conn);
                adapter.Fill(ds, "Book");        
               
            }
            DataTable dtBook = ds.Tables["Book"];
            DataTable dtCategory = ds.Tables["Category"];
            
            IEnumerable<DataRow>  enumTable = dtBook.AsEnumerable()  ;
            enumTable = enumTable.Where(
                book => book.Field<int>("BookPrice") > 400
                ) ;
               
            string str = "";
            foreach (var v in enumTable)
            {
                str += "ISBN：" + v.Field<string>("BookISBN") +
                       "　書名：" + v.Field<string>("BookTitle") +"\n";
            }
            BookRichTextBox.Text = str;
        }

    }
}
