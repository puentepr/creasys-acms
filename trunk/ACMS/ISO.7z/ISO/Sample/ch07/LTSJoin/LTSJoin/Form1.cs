﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient ;
using System.Reflection; 

namespace LTSJoin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            string sql2 = "SELECT * FROM Category";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                    adapter.Fill(ds, "Book");
                adapter =
                    new SqlDataAdapter(sql2, conn);
                adapter.Fill(ds, "Category");
            }
            DataTable dtBook = ds.Tables["Book"];
            DataTable dtCategory = ds.Tables["Category"];

            var enumTable =
                from bookTable in dtBook.AsEnumerable()  
                join catTable in dtCategory.AsEnumerable() 
                on bookTable.Field<int>("BookCategoryID") equals
                   catTable.Field<int>("CategoryID") 
                where 
                   bookTable.Field<int>("BookPrice")  > 400 
                select new
                {                   
                    bookTitle = 
                     bookTable.Field<string>("BookTitle"),
                    bookCategoryName = 
                     catTable.Field<string>("CategoryName"),
                 };
            string str = ""; 
            foreach (var v in enumTable)
            {
                str += 
                    " 分類：" + v.bookCategoryName + 
                    " 書名：" + v.bookTitle + "\n"; 
            }
            BookRichTextBox.Text = str;
        }
    }





    
}
