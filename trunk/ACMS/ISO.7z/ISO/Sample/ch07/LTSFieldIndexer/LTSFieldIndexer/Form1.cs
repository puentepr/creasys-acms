﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;


namespace LTSFieldIndexer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

    private void Form1_Load(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(
    "Data Source=.\\SQLEXPRESS;" +
    "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
    "Integrated Security=True;User Instance=True");
        string sql = "SELECT * FROM Book";
        DataSet ds = new DataSet();
        using (conn)
        {
            SqlDataAdapter adapter =
                new SqlDataAdapter(sql, conn);
            adapter.Fill(ds, "Book");
        }
        DataTable dt = ds.Tables["Book"];
        var enumTable =
            from bookTable in dt.AsEnumerable()
            where (int)bookTable["BookPrice"]  > 400 
            select new
            {
                bookISBN = (string)bookTable["BookISBN"],
                bookTitle =(string)bookTable["BookTitle"],
                bookPrice = (int)bookTable["BookPrice"],
                bookAuthor = (string)bookTable["BookAuthor"]
            };
        string str = "";
        foreach (var dr in enumTable)
        {
            str +=
                "ISBN："+dr.bookISBN + "　" +
                "價格：" + dr.bookPrice + "　" +
                "書名：" + dr.bookTitle + "/" +
                dr.bookAuthor + "\n";
        }
        BookRichTextBox.Text = str;
       

    }
    }
}
