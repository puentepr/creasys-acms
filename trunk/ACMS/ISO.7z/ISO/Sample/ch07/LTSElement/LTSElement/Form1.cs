﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSElement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void GetElement(int indexValue )
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dtBook = ds.Tables["Book"];        

            var enumTable =
                from bookTable in dtBook.AsEnumerable()
                select bookTable.Field<string>("BookTitle");

            var enumElement = enumTable.First() ;  
                if(indexValue  != 1 )
                enumElement  = enumTable.ElementAt(indexValue  -1  ); 

            BookRichTextBox.Text = enumElement.ToString()   ;           
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            GetElement(1);
        }
        private void GoButton_Click(object sender, EventArgs e)
                {
            int indexValue = int.Parse(EleTextBox.Text);
            GetElement(indexValue);
        }
    }

}
