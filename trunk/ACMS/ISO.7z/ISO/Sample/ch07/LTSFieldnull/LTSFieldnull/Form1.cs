﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace LTSFieldnull
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
        "Data Source=.\\SQLEXPRESS;" +
        "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
        "Integrated Security=True;User Instance=True");
            string sql = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dt = ds.Tables["Book"];
            var enumTable =
                from bookTable in dt.AsEnumerable()
                select new
                {
                    //bookTitle =(string)bookTable["BookTitle"],
                    //bookAuthor = (string)bookTable["BookAuthor"],
                    bookTitle = bookTable.Field<string>("BookTitle"),
                    bookAuthor = bookTable.Field<string>("BookAuthor"),
                };
            try
            {

                string str = "";
                foreach (var dr in enumTable)
                {
                    str += dr.bookTitle + "/" +
                           dr.bookAuthor + "\n";
                }
                BookRichTextBox.Text =str;
            }
            catch (InvalidCastException ex)
            {
                BookRichTextBox.Text = "錯誤訊息:\n"+ex.Message;
            }

        }

    }
}
