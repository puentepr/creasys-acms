﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient; 
using System.Text;
using System.Windows.Forms;

namespace ULINQtoDataSet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                    "Data Source=.\\SQLEXPRESS;" +
                    "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                    "Integrated Security=True;User Instance=True");
            string sql = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dt = ds.Tables["Book"];
            IEnumerable<DataRow> enumTable =
                from bookTable in dt.AsEnumerable()
                select bookTable;

                string bookTitle = ""; 
            foreach (DataRow bookRow in enumTable)
            {
                bookTitle += 
                    "\nISBN:"+ bookRow[0].ToString() + 
                    "　書名："+bookRow[1].ToString()      ;
            }
            BookRichTextBox.Text = bookTitle ; 
        }
    }
}
