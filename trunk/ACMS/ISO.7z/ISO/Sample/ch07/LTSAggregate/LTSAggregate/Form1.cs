﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient ;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSAggregate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
            "Data Source=.\\SQLEXPRESS;" +
            "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
            "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dtBook = ds.Tables["Book"];

            var enumTable =
                from bookTable in dtBook.AsEnumerable()
                group bookTable by
                      bookTable.Field<int>("BookCategoryID")
                    into g
                    select new { 
                        categoryID = g.Key,
                        average = g.Average(bookRow=>bookRow.Field<int>("BookPrice"))
                    };
            string str = "";
            foreach (var ig in enumTable)
            {
                str += "分類編號:" + ig.categoryID + 
                       "平均價格:" + ig.average.ToString()  +  "\n";
            }
            BookRichTextBox.Text = str;     
        }
    }
}
