﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSAggregate
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                        "Data Source=.\\SQLEXPRESS;" +
                        "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                        "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dtBook = ds.Tables["Book"];

            var enumTable =
                from bookTable in dtBook.AsEnumerable()
                group bookTable by
                      bookTable.Field<int>("BookCategoryID")
                    into g
                    select new
                    {
                        categoryID = g.Key,
                        Average = g.Average(bookRow => bookRow.Field<int>("BookPrice")),
                        sum = g.Sum(bookRow => bookRow.Field<int>("BookPrice")),
                        Count = g.Count(),
                        Max = g.Max(bookRow => bookRow.Field<int>("BookPrice")),
                        Min = g.Min(bookRow => bookRow.Field<int>("BookPrice")) ,  
                        bookRow  = g  
                    };
            string str = "";
            foreach (var ig in enumTable)
            {
                str += "分類編號:" + ig.categoryID +
                       " 平均價格:" + ig.Average.ToString() +
                       " 總合:" + ig.sum.ToString() +
                       " 數量:" + ig.Count.ToString() +
                       " 最貴:" + ig.Max.ToString() +
                       " 最便宜:" + ig.Min.ToString() + "\n";
                foreach(var v in ig.bookRow  )  
                    str +="　書名：" +  v.Field<string>("BookTitle")  + 
                          "　價格：" +  v.Field<int>("BookPrice") + "\n"　　　;
               
            }
            BookRichTextBox.Text = str;  
        }
    }
}
