﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient ;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSSelectMany
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
        "Data Source=.\\SQLEXPRESS;" +
        "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
        "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            string sql2 = "SELECT * FROM Category";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
                adapter =
                    new SqlDataAdapter(sql2, conn);
                adapter.Fill(ds, "Category");
            }
            DataTable dtBook = ds.Tables["Book"];
            DataTable dtCategory = ds.Tables["Category"];
            
            var enumTable =
                from bookTable in dtBook.AsEnumerable()
                from catTable in dtCategory.AsEnumerable()
                //where
                //   bookTable.Field<int>("BookCategoryID") ==
                //   catTable.Field<int>("CategoryID") &&
                //   bookTable.Field<int>("BookPrice") > 400
                select new
                {
                    bookISBN = bookTable.Field<string>("BookISBN"),
                    bookTitle = bookTable.Field<string>("BookTitle"),
                    bookCategoryName = catTable.Field<string>("CategoryName"),
                    bookPrice = bookTable.Field<int>("BookPrice"),
                    bookAuthor = bookTable.Field<string>("BookAuthor")
                };

            string str = ""; 
            foreach (var v in enumTable)
            {
                str += "ISBN：" + v.bookISBN +
                       "　（分類）書名：（" + v.bookCategoryName + "）" + v.bookTitle +
                       "　價格：" + v.bookPrice + "\n"; 
            }
            BookRichTextBox.Text = str;
        }
    }
}
