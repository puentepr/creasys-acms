﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;
namespace ULTDTrans
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter = new SqlDataAdapter(sql, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dt = ds.Tables["Book"];
            
            //EnumerableRowCollection<DataRow> enumTable =
            //    from bookTable in dt.AsEnumerable()
            //    select new
            //    {
            //        bookID = bookTable.Field<string>("BookID"),
            //        bookTitle = bookTable.Field<string>("BookTitle"),
            //        bookISBN = bookTable.Field<string>("BookISBN")
            //    };


            var enumTable =
            from bookTable in dt.AsEnumerable()
            select new
            {
                bookID = bookTable.Field<int>("BookID"),
                bookTitle = bookTable.Field<string>("BookTitle"),
                bookISBN = bookTable.Field<string>("BookISBN")
            };
            DataTable dv = enumTable.CopyToDataTable(); 
            BookDataGridView.DataSource = dv; 

            
        }
    }
}
