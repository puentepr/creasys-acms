﻿namespace LTSElementMethod
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.EleTextBox = new System.Windows.Forms.TextBox();
            this.GoButton = new System.Windows.Forms.Button();
            this.BookRichTextBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // EleTextBox
            // 
            this.EleTextBox.Location = new System.Drawing.Point(12, 12);
            this.EleTextBox.Name = "EleTextBox";
            this.EleTextBox.Size = new System.Drawing.Size(81, 22);
            this.EleTextBox.TabIndex = 6;
            this.EleTextBox.Text = "1";
            // 
            // GoButton
            // 
            this.GoButton.Location = new System.Drawing.Point(99, 11);
            this.GoButton.Name = "GoButton";
            this.GoButton.Size = new System.Drawing.Size(75, 23);
            this.GoButton.TabIndex = 5;
            this.GoButton.Text = "搜尋";
            this.GoButton.UseVisualStyleBackColor = true;
            this.GoButton.Click += new System.EventHandler(this.GoButton_Click);
            // 
            // BookRichTextBox
            // 
            this.BookRichTextBox.Location = new System.Drawing.Point(12, 40);
            this.BookRichTextBox.Name = "BookRichTextBox";
            this.BookRichTextBox.Size = new System.Drawing.Size(327, 91);
            this.BookRichTextBox.TabIndex = 4;
            this.BookRichTextBox.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 139);
            this.Controls.Add(this.EleTextBox);
            this.Controls.Add(this.GoButton);
            this.Controls.Add(this.BookRichTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox EleTextBox;
        private System.Windows.Forms.Button GoButton;
        private System.Windows.Forms.RichTextBox BookRichTextBox;
    }
}

