﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient ;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSElementMethod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void GetElement()
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dtBook = ds.Tables["Book"];
            try
            {
                var enumTable =
                    dtBook.AsEnumerable().First(
                        book => book.Field<string>
                          ("BookTitle").Contains(EleTextBox.Text));              
                BookRichTextBox.Text = 
                        enumTable.Field<string>("BookTitle");
            }
            catch (InvalidOperationException ioex)
            {
                MessageBox.Show(ioex.Message); 
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            GetElement();
        }
        private void GoButton_Click(object sender, EventArgs e)
        {
            GetElement();
        }
    }
}
