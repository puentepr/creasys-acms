﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient ;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace LTSGroup
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dtBook = ds.Tables["Book"];

            var enumTable =
                from bookTable in dtBook.AsEnumerable()
                group bookTable by bookTable.Field<int>("BookCategoryID");
                
            string str  = ""  ; 
            foreach(IGrouping<int,DataRow> ig in enumTable )
            {
                str += "分類編號:" + ig.Key.ToString() + "\n";
                foreach (var v in ig)
                {
                    str += "　書名：" + v.Field<string>("BookTitle") + "\n";
                }
            }



            BookRichTextBox.Text = str;          
        }

    }
}
