﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient; 
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSGroup
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                        "Data Source=.\\SQLEXPRESS;" +
                        "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                        "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dtBook = ds.Tables["Book"];

            var enumTable =
                from bookTable in dtBook.AsEnumerable()
                group bookTable by
                      bookTable.Field<int>("BookCategoryID")
                    into g
                    select new { categoryID = g.Key } ;                 

            string str = "";
            foreach (var  ig in enumTable)
            {
                str += "分類編號:" + ig.categoryID  + "\n";
            }
            BookRichTextBox.Text = str;     
        }
    }
}
