﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient; 
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSAggregateMethod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                        "Data Source=.\\SQLEXPRESS;" +
                        "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                        "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dtBook = ds.Tables["Book"];
            var enumTable = dtBook.AsEnumerable();
            int total = enumTable.Sum(t => t.Field<int>("BookPrice"));
            double ave  =  enumTable.Average(t => t.Field<int>("BookPrice"));
            int max = enumTable.Max(t => t.Field<int>("BookPrice"));
            int min = enumTable.Min(t => t.Field<int>("BookPrice"));
            int count = enumTable.Count();

            string str = "書籍彙總資料\n";
            str += "總合：" + total + "\n";
            str += "平均：" + ave + "\n";
            str += "最高：" + max + "\n";
            str += "最低：" + min + "\n";
            str += "數量：" + count + "\n";

            BookRichTextBox.Text = str;  
          　　
          
        }
    }
}
