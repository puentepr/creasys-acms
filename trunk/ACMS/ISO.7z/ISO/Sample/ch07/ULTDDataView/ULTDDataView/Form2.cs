﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;


namespace ULTDDataView
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter = 
                    new SqlDataAdapter(sql, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dt = ds.Tables["Book"];
            EnumerableRowCollection<DataRow> enumTable =
                from bookTable in dt.AsEnumerable()
                select bookTable;

            DataTable dtCopy = enumTable.CopyToDataTable();
            BookTabledataGridView.DataSource = dtCopy; 
            DataView dv = new DataView(dtCopy);
            BookDataGridView.DataSource = dtCopy ; 

        }
    }
}
