﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSSelectMethod
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql, conn);
                adapter.Fill(ds, "Book");
               
            }
            DataTable dtBook = ds.Tables["Book"];


            var enumTable = dtBook.AsEnumerable().Select(
                    book => new {
                        bookISBN = book.Field<string>("BookISBN"),
                        bookTitle = book.Field<string>("BookTitle"),
                        bookPrice = book.Field<int>("BookPrice"),
                        bookAuthor = book.Field<string>("BookAuthor")
                });

            string str = "";
            foreach (var v in enumTable)
            {
                str += "ISBN：" + v.bookISBN +
                       " 書名：" +  v.bookTitle +
                       "　價格：" + v.bookPrice + "\n";
            }
            BookRichTextBox.Text = str;
        }
    }
}
