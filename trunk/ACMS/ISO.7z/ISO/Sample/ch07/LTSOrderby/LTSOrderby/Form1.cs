﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;  
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSOrderby
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            sortData();
        }
        private void sortData()
        {
            SqlConnection conn = new SqlConnection(
                "Data Source=.\\SQLEXPRESS;" +
                "AttachDbFilename=|DataDirectory|\\DBooks.mdf;" +
                "Integrated Security=True;User Instance=True");
            string sql1 = "SELECT * FROM Book";
            DataSet ds = new DataSet();
            using (conn)
            {
                SqlDataAdapter adapter =
                    new SqlDataAdapter(sql1, conn);
                adapter.Fill(ds, "Book");
            }
            DataTable dtBook = ds.Tables["Book"];
            string sortField = FieldComboBox.Text;
            int intSort = 0;
            if (sortField == "")
                sortField = "BookTitle";
            if(OrderTextBox.Text != "" )
                intSort  =int.Parse(OrderTextBox.Text);

            var enumTable =
                from bookTable in dtBook.AsEnumerable()
                orderby bookTable.Field<string>(sortField).Substring(intSort)
                select new
                {
                    bookISBN = bookTable.Field<string>("BookISBN"),
                    bookTitle = bookTable.Field<string>("BookTitle"),
                    bookPrice = bookTable.Field<int>("BookPrice"),
                    bookAuthor = bookTable.Field<string>("BookAuthor")
                };
            string str = "";
            foreach (var v in enumTable)
            {
                str += "ISBN：" + v.bookISBN +
                       "　作者：" + v.bookAuthor +
                       "　書名：" + v.bookTitle +                       
                       "　價格：" + v.bookPrice + "\n";
            }
            BookRichTextBox.Text = str;
        }
        private void GoButton_Click(object sender, EventArgs e)
        {
            sortData();
        }

    }
}
