﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq; 

namespace LINQDBtoXML
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void DBXMLButton_Click(object sender, EventArgs e)
        {
            BookDataClassesDataContext context =
                new BookDataClassesDataContext();
            XElement  enumBook =
                new XElement("Books",
               from book in context.Book
               select new XElement("Book",
                 new XElement("BookTitle", book.BookTitle),
                 new XElement("BookISBN", book.BookISBN),
                 new XElement("BookAuthor", book.BookAuthor))
             );
            XMLRichTextBox.Text   = enumBook.ToString();  
        }
    }
}
