﻿namespace UORDesignerSPCode
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.GoButton = new System.Windows.Forms.Button();
            this.bookIDTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ISBNLabel = new System.Windows.Forms.Label();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.authorLabel = new System.Windows.Forms.Label();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.GoPriceButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // GoButton
            // 
            this.GoButton.Location = new System.Drawing.Point(213, 10);
            this.GoButton.Name = "GoButton";
            this.GoButton.Size = new System.Drawing.Size(60, 29);
            this.GoButton.TabIndex = 0;
            this.GoButton.Text = "搜尋";
            this.GoButton.UseVisualStyleBackColor = true;
            this.GoButton.Click += new System.EventHandler(this.GoButton_Click);
            // 
            // bookIDTextBox
            // 
            this.bookIDTextBox.Location = new System.Drawing.Point(106, 15);
            this.bookIDTextBox.Name = "bookIDTextBox";
            this.bookIDTextBox.Size = new System.Drawing.Size(91, 22);
            this.bookIDTextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "書籍編號：";
            // 
            // ISBNLabel
            // 
            this.ISBNLabel.AutoSize = true;
            this.ISBNLabel.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ISBNLabel.Location = new System.Drawing.Point(12, 62);
            this.ISBNLabel.Name = "ISBNLabel";
            this.ISBNLabel.Size = new System.Drawing.Size(42, 16);
            this.ISBNLabel.TabIndex = 3;
            this.ISBNLabel.Text = "ISBN";
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.TitleLabel.Location = new System.Drawing.Point(12, 87);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(72, 16);
            this.TitleLabel.TabIndex = 4;
            this.TitleLabel.Text = "書籍名稱";
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.priceLabel.Location = new System.Drawing.Point(12, 159);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(72, 16);
            this.priceLabel.TabIndex = 5;
            this.priceLabel.Text = "書籍售價";
            // 
            // authorLabel
            // 
            this.authorLabel.AutoSize = true;
            this.authorLabel.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.authorLabel.Location = new System.Drawing.Point(12, 113);
            this.authorLabel.Name = "authorLabel";
            this.authorLabel.Size = new System.Drawing.Size(72, 16);
            this.authorLabel.TabIndex = 6;
            this.authorLabel.Text = "書籍作者";
            // 
            // priceTextBox
            // 
            this.priceTextBox.Location = new System.Drawing.Point(111, 159);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(50, 22);
            this.priceTextBox.TabIndex = 7;
            this.priceTextBox.Text = "0";
            // 
            // GoPriceButton
            // 
            this.GoPriceButton.Location = new System.Drawing.Point(177, 154);
            this.GoPriceButton.Name = "GoPriceButton";
            this.GoPriceButton.Size = new System.Drawing.Size(74, 29);
            this.GoPriceButton.TabIndex = 8;
            this.GoPriceButton.Text = "修改價格";
            this.GoPriceButton.UseVisualStyleBackColor = true;
            this.GoPriceButton.Click += new System.EventHandler(this.GoPriceButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 213);
            this.Controls.Add(this.GoPriceButton);
            this.Controls.Add(this.priceTextBox);
            this.Controls.Add(this.authorLabel);
            this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.TitleLabel);
            this.Controls.Add(this.ISBNLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bookIDTextBox);
            this.Controls.Add(this.GoButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button GoButton;
        private System.Windows.Forms.TextBox bookIDTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ISBNLabel;
        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label authorLabel;
        private System.Windows.Forms.TextBox priceTextBox;
        private System.Windows.Forms.Button GoPriceButton;
    }
}

