﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UORDesignerSPCode
{
    public partial class Form1 : Form
    {
        DataClassesSPCodeDataContext context =
            new DataClassesSPCodeDataContext();

        public Form1()
        {
            InitializeComponent();
        }

        private void GoButton_Click(object sender, EventArgs e)
        {
            foreach (SelectBook結果 result in 
                   context.SelectBook(int.Parse(bookIDTextBox.Text) ))
            {
                ISBNLabel.Text = result.BookISBN;
                TitleLabel.Text = result.BookTitle;
                authorLabel.Text = result.BookAuthor;
                priceLabel.Text = result.BookPrice.ToString()  ;
            }
        }

        private void GoPriceButton_Click(object sender, EventArgs e)
        {
            context.UpdateBook(
                int.Parse(bookIDTextBox.Text),
                int.Parse(priceTextBox.Text)); 
            MessageBox.Show("資料更新完成…") ; 
        }
    }
}
