﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using System.Data.Linq.Mapping;


namespace LTSSelect
{
    class Program
    {
        static void Main(string[] args)
        {

            string path = System.Environment.CurrentDirectory + "\\DBooks.mdf";
            DataContext dc = new DataContext(path);

            Table<CBook> tbBook = dc.GetTable<CBook>(); 
            //var enumBook =
            //    from a in tbBook
            //    select a.BookTitle;
            //foreach (var str in enumBook)
            //    Console.WriteLine(str.ToString());

                var enumBook =
                    from a in tbBook
                    select a ;
                foreach (var a in enumBook)
                    Console.WriteLine(
                        "編號:" + a.BookID.ToString() + "," +
                        "書名:" + a.BookTitle );
            Console.Read();
        }
        [Table(Name = "Book")]
        public class CBook
        {
            [Column]
            public int  BookID;
            [Column]
            public string BookTitle;
        }
    }
}
