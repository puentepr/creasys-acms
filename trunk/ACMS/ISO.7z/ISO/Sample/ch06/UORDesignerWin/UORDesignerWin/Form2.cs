﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UORDesignerWin
{
    public partial class Form2 : Form
    {
        
        private DBookDataContext context = null; 
        public Form2()
        {
            InitializeComponent();
            
            string PATH = System.Environment.CurrentDirectory+"\\DBOOKS.MDF";
            context = new DBookDataContext(PATH);
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            bookBindingSource.DataSource = context.Book;
        }

        private void bookBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            context.SubmitChanges(); 
        }
    }
}
