﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UORDesignerWin
{
    public partial class Form3 : Form
    {
        private DBookDataContext context = null; 

        public Form3()
        {
            InitializeComponent();

            string PATH =System.Environment.CurrentDirectory+ "\\DBOOKS.MDF";
            context = new DBookDataContext(PATH);
        }
        private void bookBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
             context.SubmitChanges(); 
        }
        private void Form3_Load(object sender, EventArgs e)
        {
                bookBindingSource.DataSource = context.Book; 
        }
        private void GoButton_Click(object sender, EventArgs e)
        {
            var bookResult =
                from sBook in context.Book
                where
                  sBook.BookISBN == conditionTextBox.Text ||
                  sBook.BookTitle == conditionTextBox.Text ||
                  sBook.BookAuthor == conditionTextBox.Text
                select sBook;
            bookBindingSource.DataSource = bookResult ;
        }
    }
}
