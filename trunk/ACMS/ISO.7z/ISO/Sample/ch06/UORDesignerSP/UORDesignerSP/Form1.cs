﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UORDesignerSP
{
    public partial class Form1 : Form
    {
        DataClasses1DataContext context = null; 
        public Form1()
        {
            InitializeComponent();
            string path =System.Environment.CurrentDirectory+   "\\DBOOKS.MDF";
            context = new DataClasses1DataContext(path); 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            categoryBindingSource.DataSource = context.Category;  
        }

        private void categoryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            context.SubmitChanges();
            MessageBox.Show("資料更新完成…"); 
        }
    }
}
