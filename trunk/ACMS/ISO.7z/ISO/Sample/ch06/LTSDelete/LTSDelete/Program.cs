﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace LTSDelete
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = System.Environment.CurrentDirectory+"\\DBooks.mdf";
            DataContext dc = new DataContext(path);
            var enumBook =
               from a in dc.GetTable<CBook>()
               where a.BookID == 1006
               select a;

            dc.GetTable<CBook>().DeleteOnSubmit(enumBook.First());
            dc.SubmitChanges();
            Console.WriteLine("資料刪除完成 ... ");
            Console.Read();
        }
        [Table(Name = "Book")]
        public class CBook
        {
            [Column(IsPrimaryKey = true)]
            public int BookID = 0;
            [Column]
            public string BookTitle = "";
            [Column]
            public int BookPrice = 0;
            [Column]
            public string BookAuthor = "";
            [Column]
            public string BookISBN = "";
            [Column]
            public int BookCategoryID = 0;

        }
    }   

}
