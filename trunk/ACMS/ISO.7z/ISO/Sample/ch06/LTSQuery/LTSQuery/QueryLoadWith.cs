﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Linq     ;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class QueryLoadWith : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext();

        public QueryLoadWith()
        {
            InitializeComponent();
        }
        private void QueryLoadWith_Load(object sender, EventArgs e)
        {
            DataLoadOptions dlo = new DataLoadOptions();
            dlo.LoadWith<Category>(cat => cat.Book);
            context.LoadOptions = dlo;
            var loadCat =
                from cat in context.Category
                where cat.CategoryName == "Design"  
                select cat.Book   ;

            string message = "以下列舉設計類(Design)的圖書：\n";
            foreach (var b in loadCat)
            {               
                foreach (var a in b)
                {
                    message += "\n　　*"+a.BookTitle;
                }
            }
            CatBookRichTextBox.Text = message;
        }
    }
}
