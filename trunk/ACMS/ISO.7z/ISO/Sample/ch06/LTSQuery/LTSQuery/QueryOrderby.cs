﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class QueryOrderby : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext(); 

        public QueryOrderby()
        {
            InitializeComponent();
        }
        private void OrderbyComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int orderField  = OrderbyComboBox.SelectedIndex    ;
            IQueryable enumQuery = null; 
            
            switch(orderField)
            {
                case 0:
                  enumQuery =
                      from books in context.Book
                      orderby books.BookTitle,books.BookID
                      select books; 
                  break   ;
                case 1:
                  enumQuery =
                      from books in context.Book
                      orderby books.BookAuthor, books.BookID 
                      select books; 
                  break;
                case 2:
                  enumQuery =
                      from books in context.Book
                      orderby books.BookPrice
                      select books; 
                  break;
                case 3:
                  enumQuery =
                      from books in context.Book
                      orderby books.BookID 
                      select books;
                  break;
            }
            BookDataGridView.DataSource = enumQuery;
            
        }
    }
}
