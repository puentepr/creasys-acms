﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class QueryUnion : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext(); 
        public QueryUnion()
        {
            InitializeComponent();
        }
        private void UnionButton_Click(object sender, EventArgs e)
        {
           var queryEnum =
                (from book in context.Book
                 select("書籍：" +  book.BookTitle )).Union(
                 from soft in context.Software
                 select ("軟體：" + soft.SoftwareName) 
                );
            UnionListBox.DataSource = queryEnum; 
         }
    }
}
