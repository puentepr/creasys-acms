﻿namespace LTSQuery
{
    partial class FormMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.WhereButton = new System.Windows.Forms.Button();
            this.OrderbyButton = new System.Windows.Forms.Button();
            this.GroupbyButton = new System.Windows.Forms.Button();
            this.UnionButton = new System.Windows.Forms.Button();
            this.DifferenceButton = new System.Windows.Forms.Button();
            this.AsEnumerableButton = new System.Windows.Forms.Button();
            this.QueryArrayListButton = new System.Windows.Forms.Button();
            this.QueryLoadWithButton1 = new System.Windows.Forms.Button();
            this.QueryAssociateWithButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WhereButton
            // 
            this.WhereButton.Location = new System.Drawing.Point(35, 13);
            this.WhereButton.Name = "WhereButton";
            this.WhereButton.Size = new System.Drawing.Size(114, 23);
            this.WhereButton.TabIndex = 0;
            this.WhereButton.Text = "QueryWhere";
            this.WhereButton.UseVisualStyleBackColor = true;
            this.WhereButton.Click += new System.EventHandler(this.WhereButton_Click);
            // 
            // OrderbyButton
            // 
            this.OrderbyButton.Location = new System.Drawing.Point(35, 42);
            this.OrderbyButton.Name = "OrderbyButton";
            this.OrderbyButton.Size = new System.Drawing.Size(114, 23);
            this.OrderbyButton.TabIndex = 2;
            this.OrderbyButton.Text = "QueryOrderby";
            this.OrderbyButton.UseVisualStyleBackColor = true;
            this.OrderbyButton.Click += new System.EventHandler(this.OrderbyButton_Click);
            // 
            // GroupbyButton
            // 
            this.GroupbyButton.Location = new System.Drawing.Point(35, 71);
            this.GroupbyButton.Name = "GroupbyButton";
            this.GroupbyButton.Size = new System.Drawing.Size(114, 23);
            this.GroupbyButton.TabIndex = 3;
            this.GroupbyButton.Text = "QueryGroupby";
            this.GroupbyButton.UseVisualStyleBackColor = true;
            this.GroupbyButton.Click += new System.EventHandler(this.GroupbyButton_Click);
            // 
            // UnionButton
            // 
            this.UnionButton.Location = new System.Drawing.Point(35, 101);
            this.UnionButton.Name = "UnionButton";
            this.UnionButton.Size = new System.Drawing.Size(114, 23);
            this.UnionButton.TabIndex = 4;
            this.UnionButton.Text = "QueryUnion";
            this.UnionButton.UseVisualStyleBackColor = true;
            this.UnionButton.Click += new System.EventHandler(this.UnionButton_Click);
            // 
            // DifferenceButton
            // 
            this.DifferenceButton.Location = new System.Drawing.Point(35, 144);
            this.DifferenceButton.Name = "DifferenceButton";
            this.DifferenceButton.Size = new System.Drawing.Size(140, 23);
            this.DifferenceButton.TabIndex = 5;
            this.DifferenceButton.Text = "QueryDifference";
            this.DifferenceButton.UseVisualStyleBackColor = true;
            this.DifferenceButton.Click += new System.EventHandler(this.DifferenceButton_Click);
            // 
            // AsEnumerableButton
            // 
            this.AsEnumerableButton.Location = new System.Drawing.Point(35, 173);
            this.AsEnumerableButton.Name = "AsEnumerableButton";
            this.AsEnumerableButton.Size = new System.Drawing.Size(140, 23);
            this.AsEnumerableButton.TabIndex = 6;
            this.AsEnumerableButton.Text = "QueryAsEnumerable";
            this.AsEnumerableButton.UseVisualStyleBackColor = true;
            this.AsEnumerableButton.Click += new System.EventHandler(this.AsEnumerableButton_Click);
            // 
            // QueryArrayListButton
            // 
            this.QueryArrayListButton.Location = new System.Drawing.Point(35, 202);
            this.QueryArrayListButton.Name = "QueryArrayListButton";
            this.QueryArrayListButton.Size = new System.Drawing.Size(140, 23);
            this.QueryArrayListButton.TabIndex = 7;
            this.QueryArrayListButton.Text = "QueryArrayList";
            this.QueryArrayListButton.UseVisualStyleBackColor = true;
            this.QueryArrayListButton.Click += new System.EventHandler(this.QueryArrayListButton_Click);
            // 
            // QueryLoadWithButton1
            // 
            this.QueryLoadWithButton1.Location = new System.Drawing.Point(35, 231);
            this.QueryLoadWithButton1.Name = "QueryLoadWithButton1";
            this.QueryLoadWithButton1.Size = new System.Drawing.Size(140, 23);
            this.QueryLoadWithButton1.TabIndex = 8;
            this.QueryLoadWithButton1.Text = "QueryLoadWith";
            this.QueryLoadWithButton1.UseVisualStyleBackColor = true;
            this.QueryLoadWithButton1.Click += new System.EventHandler(this.QueryLoadWithButton1_Click);
            // 
            // QueryAssociateWithButton
            // 
            this.QueryAssociateWithButton.Location = new System.Drawing.Point(35, 260);
            this.QueryAssociateWithButton.Name = "QueryAssociateWithButton";
            this.QueryAssociateWithButton.Size = new System.Drawing.Size(140, 23);
            this.QueryAssociateWithButton.TabIndex = 9;
            this.QueryAssociateWithButton.Text = "QueryAssociateWith";
            this.QueryAssociateWithButton.UseVisualStyleBackColor = true;
            this.QueryAssociateWithButton.Click += new System.EventHandler(this.QueryAssociateWithButton_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 304);
            this.Controls.Add(this.QueryAssociateWithButton);
            this.Controls.Add(this.QueryLoadWithButton1);
            this.Controls.Add(this.QueryArrayListButton);
            this.Controls.Add(this.AsEnumerableButton);
            this.Controls.Add(this.DifferenceButton);
            this.Controls.Add(this.UnionButton);
            this.Controls.Add(this.GroupbyButton);
            this.Controls.Add(this.OrderbyButton);
            this.Controls.Add(this.WhereButton);
            this.Name = "FormMain";
            this.Text = "範例主選單";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button WhereButton;
        private System.Windows.Forms.Button OrderbyButton;
        private System.Windows.Forms.Button GroupbyButton;
        private System.Windows.Forms.Button UnionButton;
        private System.Windows.Forms.Button DifferenceButton;
        private System.Windows.Forms.Button AsEnumerableButton;
        private System.Windows.Forms.Button QueryArrayListButton;
        private System.Windows.Forms.Button QueryLoadWithButton1;
        private System.Windows.Forms.Button QueryAssociateWithButton;
    }
}

