﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class QueryArrayList : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext();
        public QueryArrayList()
        {
            InitializeComponent();
        }

        private void GoButton_Click(object sender, EventArgs e)
        {
            var enumBook =
                 from books in context.Book.AsEnumerable()
                 where books.BookPrice > int.Parse(PriceTextBox.Text) 
                 select books;

            Book[] enumBookArray = enumBook.ToArray(); 
            string str = "";
            foreach (Book value in enumBookArray)
            {
                str += "\n" + value.BookTitle    ;
            }

            List<Book> enumBookList = enumBook.ToList();


            BookDataGridView.DataSource = enumBookList; 
            BookRichTextBox.Text = str;
        }
    }
}
