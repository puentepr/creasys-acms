﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class QueryWhere : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext(); 

        public QueryWhere()
        {
            InitializeComponent();
        }
        private void GoButton_Click(object sender, EventArgs e)
        {
            string condition = ConditionTextBox.Text;
            IQueryable enrumQuery =
                from book in context.Book
                where 
                book.BookTitle.Contains(condition)  ||
                book.BookAuthor.Contains(condition) ||
                book.BookISBN.Contains(condition) 
                select book;
            BookDataGridView.DataSource = enrumQuery; 
        }
        private void QueryWhere_Load(object sender, EventArgs e)
        {
            CatComboBox.DataSource = context.Category; ;
            CatComboBox.DisplayMember = "CategoryName";
            CatComboBox.ValueMember = "CategoryID";
            CatComboBox.SelectedIndex = 0; 
        }
        private void CatComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string  condition =((ComboBox)sender).SelectedValue.ToString()   ; 
            int conditionVlaue  = 0  ;
            int.TryParse(condition,out  conditionVlaue);
             
            IQueryable enrumQuery =
                from book in context.Book 
                where
                book.BookCategoryID == conditionVlaue               
                select book;
            BookDataGridView.DataSource = enrumQuery    ;
        }
        private void GoButtonPrice_Click(object sender, EventArgs e)
        {
            if (MinTextBox.Text == "" || MaxTextBox.Text == "")
            {
                MessageBox.Show("請輸入欲查詢的價格區間 …");
                return; 
            }
            int minPrice = int.Parse(MinTextBox.Text);
            int maxPrice = int.Parse(MaxTextBox.Text);

            IQueryable enrumQuery =
                from book in context.Book
                where
                book.BookPrice >= minPrice && book.BookPrice <= maxPrice
                select book;
            BookDataGridView.DataSource = enrumQuery;

        }
    }
}
