﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class QueryGroupby : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext(); 

        public QueryGroupby()
        {
            InitializeComponent();
        }
        private void GroupButton_Click(object sender, EventArgs e)
        {
            IQueryable<IGrouping<int?, Book>> queryEnum =
                from book in context.Book
                group book by book.BookPrice   ;

            string bookGroup = ""   ; 
            foreach (IGrouping<int?, Book> ig in queryEnum)
            {
                bookGroup +="\n價格："+ ig.Key.ToString()　　; 
                foreach (Book b in ig)
                {
                    bookGroup +="\n　*"+b.BookTitle    ;
                }   
            }
            GroupRichTextBox.Text   = bookGroup   ;
        } 
    }
}
