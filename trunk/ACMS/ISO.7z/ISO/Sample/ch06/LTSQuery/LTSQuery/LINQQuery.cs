namespace LTSQuery
{
    partial class LINQQueryDataContext
    {
    }
}
