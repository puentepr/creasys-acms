﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class QueryDifference : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext();
        public QueryDifference()
        {
            InitializeComponent();
        }
        private void UnionButton_Click(object sender, EventArgs e)
        {
            var queryEnum =
                 (from soft in context.Software
                  select (soft.SoftwareCategoryID)).Except(
                  from book in context.Book
                  select (book.BookCategoryID)
                  );
            UnionListBox.DataSource = queryEnum; 
         }

        private void button1_Click(object sender, EventArgs e)
        {
            var queryEnum =
             (from soft in context.Software
              select (soft.SoftwareCategoryID)).Intersect(
              from book in context.Book
              select (book.BookCategoryID)
      );
            UnionListBox.DataSource = queryEnum; 
        }
    }
}
