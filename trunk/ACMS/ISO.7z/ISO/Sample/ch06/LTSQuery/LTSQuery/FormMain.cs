﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void WhereButton_Click(object sender, EventArgs e)
        {
            QueryWhere whereForm = new QueryWhere();
            whereForm.Show();
        }

        private void OrderbyButton_Click(object sender, EventArgs e)
        {
            QueryOrderby OrderbyForm = new QueryOrderby();
            OrderbyForm.Show();
        }

        private void GroupbyButton_Click(object sender, EventArgs e)
        {
            QueryGroupby GroupbyForm = new QueryGroupby();
            GroupbyForm.Show();

        }

        private void UnionButton_Click(object sender, EventArgs e)
        {
            QueryUnion QueryUnionForm = new QueryUnion();
            QueryUnionForm.Show();
        }

        private void DifferenceButton_Click(object sender, EventArgs e)
        {
            QueryDifference QueryDifferenceForm = new QueryDifference();
            QueryDifferenceForm.Show();
        }

        private void AsEnumerableButton_Click(object sender, EventArgs e)
        {
            QueryAsEnumerable QueryAsEnumerableForm = new QueryAsEnumerable();
            QueryAsEnumerableForm.Show();

        }

        private void QueryArrayListButton_Click(object sender, EventArgs e)
        {
            QueryArrayList QueryArrayListButtonForm = new QueryArrayList();
            QueryArrayListButtonForm.Show();
        }
        private void QueryLoadWithButton1_Click(object sender, EventArgs e)
        {
            QueryLoadWith QueryLoadWithButton = new QueryLoadWith(); 
            QueryLoadWithButton.Show() ; 

        }

        private void QueryAssociateWithButton_Click(object sender, EventArgs e)
        {
            QueryAssociateWith QueryAssociateWithForm = new QueryAssociateWith();
            QueryAssociateWithForm.Show();
        }


    }
}
