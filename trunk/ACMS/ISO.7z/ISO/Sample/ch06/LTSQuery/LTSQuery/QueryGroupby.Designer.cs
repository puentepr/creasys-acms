﻿namespace LTSQuery
{
    partial class QueryGroupby
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupButton = new System.Windows.Forms.Button();
            this.GroupRichTextBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // GroupButton
            // 
            this.GroupButton.Location = new System.Drawing.Point(13, 308);
            this.GroupButton.Name = "GroupButton";
            this.GroupButton.Size = new System.Drawing.Size(371, 23);
            this.GroupButton.TabIndex = 0;
            this.GroupButton.Text = "載入群組資料";
            this.GroupButton.UseVisualStyleBackColor = true;
            this.GroupButton.Click += new System.EventHandler(this.GroupButton_Click);
            // 
            // GroupRichTextBox
            // 
            this.GroupRichTextBox.Location = new System.Drawing.Point(13, 13);
            this.GroupRichTextBox.Name = "GroupRichTextBox";
            this.GroupRichTextBox.Size = new System.Drawing.Size(548, 289);
            this.GroupRichTextBox.TabIndex = 1;
            this.GroupRichTextBox.Text = "";
            // 
            // QueryGroupby
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 341);
            this.Controls.Add(this.GroupRichTextBox);
            this.Controls.Add(this.GroupButton);
            this.Name = "QueryGroupby";
            this.Text = "QueryGroupby";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button GroupButton;
        private System.Windows.Forms.RichTextBox GroupRichTextBox;

    }
}