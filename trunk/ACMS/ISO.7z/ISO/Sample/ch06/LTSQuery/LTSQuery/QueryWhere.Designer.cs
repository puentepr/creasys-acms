﻿namespace LTSQuery
{
    partial class QueryWhere
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ConditionTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BookDataGridView = new System.Windows.Forms.DataGridView();
            this.GoButton = new System.Windows.Forms.Button();
            this.CatComboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.MinTextBox = new System.Windows.Forms.TextBox();
            this.MaxTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.GoButtonPrice = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.BookDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ConditionTextBox
            // 
            this.ConditionTextBox.Location = new System.Drawing.Point(131, 39);
            this.ConditionTextBox.Name = "ConditionTextBox";
            this.ConditionTextBox.Size = new System.Drawing.Size(230, 22);
            this.ConditionTextBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(11, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "書名/ISBN/作者";
            // 
            // BookDataGridView
            // 
            this.BookDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BookDataGridView.Location = new System.Drawing.Point(9, 78);
            this.BookDataGridView.Name = "BookDataGridView";
            this.BookDataGridView.RowTemplate.Height = 24;
            this.BookDataGridView.Size = new System.Drawing.Size(883, 357);
            this.BookDataGridView.TabIndex = 2;
            // 
            // GoButton
            // 
            this.GoButton.Location = new System.Drawing.Point(367, 38);
            this.GoButton.Name = "GoButton";
            this.GoButton.Size = new System.Drawing.Size(75, 23);
            this.GoButton.TabIndex = 3;
            this.GoButton.Text = "查詢";
            this.GoButton.UseVisualStyleBackColor = true;
            this.GoButton.Click += new System.EventHandler(this.GoButton_Click);
            // 
            // CatComboBox
            // 
            this.CatComboBox.FormattingEnabled = true;
            this.CatComboBox.Location = new System.Drawing.Point(131, 12);
            this.CatComboBox.Name = "CatComboBox";
            this.CatComboBox.Size = new System.Drawing.Size(160, 20);
            this.CatComboBox.TabIndex = 7;
            this.CatComboBox.SelectedIndexChanged += new System.EventHandler(this.CatComboBox_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(85, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "分類";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.GoButtonPrice);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.MaxTextBox);
            this.groupBox1.Controls.Add(this.MinTextBox);
            this.groupBox1.Location = new System.Drawing.Point(476, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(331, 49);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "價格區間";
            // 
            // MinTextBox
            // 
            this.MinTextBox.Location = new System.Drawing.Point(28, 18);
            this.MinTextBox.Name = "MinTextBox";
            this.MinTextBox.Size = new System.Drawing.Size(83, 22);
            this.MinTextBox.TabIndex = 0;
           
            // 
            // MaxTextBox
            // 
            this.MaxTextBox.Location = new System.Drawing.Point(134, 18);
            this.MaxTextBox.Name = "MaxTextBox";
            this.MaxTextBox.Size = new System.Drawing.Size(84, 22);
            this.MaxTextBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(117, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "~";
            // 
            // GoButtonPrice
            // 
            this.GoButtonPrice.Location = new System.Drawing.Point(237, 17);
            this.GoButtonPrice.Name = "GoButtonPrice";
            this.GoButtonPrice.Size = new System.Drawing.Size(75, 23);
            this.GoButtonPrice.TabIndex = 9;
            this.GoButtonPrice.Text = "查詢";
            this.GoButtonPrice.UseVisualStyleBackColor = true;
            this.GoButtonPrice.Click += new System.EventHandler(this.GoButtonPrice_Click);
            // 
            // QueryWhere
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 447);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CatComboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.GoButton);
            this.Controls.Add(this.BookDataGridView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ConditionTextBox);
            this.Name = "QueryWhere";
            this.Text = "Where";
            this.Load += new System.EventHandler(this.QueryWhere_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BookDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ConditionTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView BookDataGridView;
        private System.Windows.Forms.Button GoButton;
        private System.Windows.Forms.ComboBox CatComboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button GoButtonPrice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox MaxTextBox;
        private System.Windows.Forms.TextBox MinTextBox;
    }
}