﻿namespace LTSQuery
{
    partial class QueryUnion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UnionButton = new System.Windows.Forms.Button();
            this.UnionListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // UnionButton
            // 
            this.UnionButton.Location = new System.Drawing.Point(12, 228);
            this.UnionButton.Name = "UnionButton";
            this.UnionButton.Size = new System.Drawing.Size(106, 26);
            this.UnionButton.TabIndex = 0;
            this.UnionButton.Text = "執行Union";
            this.UnionButton.UseVisualStyleBackColor = true;
            this.UnionButton.Click += new System.EventHandler(this.UnionButton_Click);
            // 
            // UnionListBox
            // 
            this.UnionListBox.FormattingEnabled = true;
            this.UnionListBox.ItemHeight = 12;
            this.UnionListBox.Location = new System.Drawing.Point(12, 13);
            this.UnionListBox.Name = "UnionListBox";
            this.UnionListBox.Size = new System.Drawing.Size(551, 208);
            this.UnionListBox.TabIndex = 1;
            // 
            // QueryUnion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(580, 266);
            this.Controls.Add(this.UnionListBox);
            this.Controls.Add(this.UnionButton);
            this.Name = "QueryUnion";
            this.Text = "QueryUnion";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button UnionButton;
        private System.Windows.Forms.ListBox UnionListBox;
    }
}