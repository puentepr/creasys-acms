﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LTSQuery
{
    public partial class QueryAsEnumerable : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext();

        public QueryAsEnumerable()
        {
            InitializeComponent();
        }
        private void GoButton_Click(object sender, EventArgs e)
        {
            var enumBook =
                 from books in context.Book.AsEnumerable()   
                 where CheckPrice(books)  
                 select books    ;
            string str  = "" ; 
            foreach (var b in enumBook)
            {
                str += "\n" + b.BookTitle;
            }
            
            BookRichTextBox.Text  =  str;
            
        }
        private bool CheckPrice(Book pbook)
        {
            
            if (pbook.BookPrice > int.Parse(PriceTextBox.Text))
                return true; 
            else 
                return false ;  
        }
    }
}
