﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Linq;

namespace LTSQuery
{
    public partial class QueryAssociateWith : Form
    {
        LINQQueryDataContext context = new LINQQueryDataContext();
        public QueryAssociateWith()
        {
            InitializeComponent();
        }

        private void QueryAssociateWith_Load(object sender, EventArgs e)
        {
            DataLoadOptions dlo = new DataLoadOptions();
            dlo.AssociateWith<Category>
                (cat => cat.Book.Where(book => book.BookPrice > 400));

            context.LoadOptions = dlo;
            var loadCat =
                from cat in context.Category
                where cat.CategoryName == "Design"
                select cat.Book;

            string message = "以下列舉設計類(Design)且價格大於500的圖書：\n";
            foreach (var b in loadCat)
            {
                foreach (var a in b)
                {
                    message += "\n　　*" + a.BookTitle;
                }
            }
            CatBookRichTextBox.Text = message;

        }
    }
}
