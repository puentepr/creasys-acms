﻿namespace LTSQuery
{
    partial class QueryOrderby
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BookDataGridView = new System.Windows.Forms.DataGridView();
            this.OrderbyComboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.BookDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // BookDataGridView
            // 
            this.BookDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.BookDataGridView.Location = new System.Drawing.Point(12, 55);
            this.BookDataGridView.Name = "BookDataGridView";
            this.BookDataGridView.RowTemplate.Height = 24;
            this.BookDataGridView.Size = new System.Drawing.Size(664, 357);
            this.BookDataGridView.TabIndex = 16;
            // 
            // OrderbyComboBox
            // 
            this.OrderbyComboBox.FormattingEnabled = true;
            this.OrderbyComboBox.Items.AddRange(new object[] {
            "書名（BookTitle）",
            "作者（BookAthor）",
            "價格（BookPrice）",
            "編號（BookID）"});
            this.OrderbyComboBox.Location = new System.Drawing.Point(81, 13);
            this.OrderbyComboBox.Name = "OrderbyComboBox";
            this.OrderbyComboBox.Size = new System.Drawing.Size(194, 20);
            this.OrderbyComboBox.TabIndex = 17;
            this.OrderbyComboBox.SelectedIndexChanged += new System.EventHandler(this.OrderbyComboBox_SelectedIndexChanged);
            // 
            // QueryOrderby
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 425);
            this.Controls.Add(this.OrderbyComboBox);
            this.Controls.Add(this.BookDataGridView);
            this.Name = "QueryOrderby";
            this.Text = "QueryOrderby";
            ((System.ComponentModel.ISupportInitialize)(this.BookDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView BookDataGridView;
        private System.Windows.Forms.ComboBox OrderbyComboBox;
    }
}