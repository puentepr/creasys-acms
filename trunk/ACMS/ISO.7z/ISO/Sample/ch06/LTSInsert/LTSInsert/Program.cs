﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using System.Data.Linq.Mapping;


namespace LTSInsert
{
    class Program
    {
        static void Main(string[] args)
        {
            //string path = @"C:\DBooks.mdf";          
           
            string path = System.Environment.CurrentDirectory+"\\DBooks.mdf";
            DataContext dc = new DataContext(path);
            CBook tbBook = new CBook();
            
            //這裏只是示範，請修改BookID值，避免重複值無法新增
            tbBook.BookID = 1010  ;
            tbBook.BookTitle = "LINQ 入門";
            tbBook.BookPrice = 690; 
            tbBook.BookAuthor = "呂高旭";
            tbBook.BookISBN = "000-000-000-000-000"; 
            tbBook.BookCategoryID = 2;
            Table<CBook> sBook = dc.GetTable<CBook>();  
           
            sBook.InsertOnSubmit(tbBook); 
            dc.SubmitChanges();
            Console.WriteLine("資料新增完成 ... ");
            Console.Read();
        }
        [Table(Name = "Book")]
        public class CBook
        {
            [Column(IsPrimaryKey=true)]
            public int BookID = 0 ;
            [Column]
            public string BookTitle = "" ;
            [Column]
            public int BookPrice = 0;
            [Column]            
            public string BookAuthor = "";
            [Column]
            public string BookISBN= "";
            [Column]
            public int BookCategoryID = 0 ;
            
        }
     }   
}
