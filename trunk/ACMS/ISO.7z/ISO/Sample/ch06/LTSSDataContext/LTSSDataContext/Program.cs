﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using System.Data.Linq.Mapping;

namespace LTSSDataContext
{
    class Program
    {
        static void Main(string[] args)
        {
            string path =System.Environment.CurrentDirectory+"\\DBooks.mdf";
            DBook db = new DBook(path);
            var enumBook =
               from a in db.Books 
               select a ;
            foreach (var a in enumBook)
                Console.WriteLine(
                    "書名:" +  a.BookTitle + "," +
                    "作者:" + a.BookAuthor + "," + 
                    "價格:" + a.BookPrice);

            
            Console.Read();
        }
        [Table(Name = "Book")]
        public class CBook
        {
            [Column]
            public int BookID = 0;
            [Column]
            public string BookTitle = "";
            [Column]
            public int BookPrice = 0;
            [Column]
            public string BookAuthor = "";
            [Column]
            public string BookISBN = "";
            [Column]
            public int BookCategoryID = 0;
        }
        public class DBook : DataContext
        {
            public Table<CBook> Books;           
            public DBook(string conn)
                : base(conn) { }
        }
    }


}
