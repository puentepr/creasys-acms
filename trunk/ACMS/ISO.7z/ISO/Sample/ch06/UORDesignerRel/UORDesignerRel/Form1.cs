﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UORDesignerRel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GoButton_Click(object sender, EventArgs e)
        {
            string str =""   ; 
            BookCatRelDataContext context = new BookCatRelDataContext()  ;
            var enumBook =
                from bc in context.Category
                select bc; 
            foreach (var b in enumBook)
            {
                str += "\n分類："+b.CategoryName  ; 
                foreach (var bfield in b.Book)
                {
                    str += "\n  * ISBN:" +
                        bfield.BookISBN +
                        "　　書名：" + bfield.BookTitle +
                        "／" +bfield.BookAuthor ; 
                }
            }
            contentRichTextBox.Text = str;
        }
    }
}
