﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UORDesignerRel
{
    public partial class Form3 : Form
    {
        BookCatRelDataContext context =
            new BookCatRelDataContext();

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            var enumCat = context.Category.Select(
                name => name.CategoryName); 
            foreach(var item in enumCat)
            {
                catToolStripComboBox.Items.Add(item.ToString());
            }
            catToolStripComboBox.SelectedIndex = 0; 
        }

        private void catToolStripComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ToolStripComboBox cComboBox = (ToolStripComboBox)sender;
            string categoryName = cComboBox.Text;

            var enumBook =
                from bc in context.Category
                select bc;
            foreach (var b in enumBook)
            {
                if (b.CategoryName == categoryName)
                {
                    bookBindingSource.DataSource = b.Book;
                    return;
                }
            }

        }

    }
}
