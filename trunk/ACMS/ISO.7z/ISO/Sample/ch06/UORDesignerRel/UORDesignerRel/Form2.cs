﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace UORDesignerRel
{
    public partial class Form2 : Form
    {
        BookCatRelDataContext context = 
            new BookCatRelDataContext();
        public Form2()
        {
            InitializeComponent();
        }
        private void Form2_Load(object sender, EventArgs e)
        {            
            categoryComboBox.DataSource = 
                context.Category.Select(
                name => name.CategoryName); 
        }
        private void categoryComboBox_SelectedValueChanged(
            object sender, EventArgs e)
        {
            ComboBox cComboBox = (ComboBox)sender;
            string categoryName = cComboBox.Text;

            var enumBook =
                from bc in context.Category
                select bc;
            foreach (var b in enumBook)
            {
                if (b.CategoryName  == categoryName)
                {
                    bookDataGridView.DataSource = b.Book     ;
                    return;
                }
            }
        }
    }
}
