﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UORDesigner
{
    class Program
    {
        static void Main(string[] args)
        {
            DataClasses1DataContext context = 
                new DataClasses1DataContext(); 
            var enumBook =
               from a in context.Book 
               select a ;
            foreach (var a in enumBook)
                Console.WriteLine(
                    "書名:" +  a.BooKTitle+ "," +
                    "作者:" + a.BookAuthor + "," + 
                    "價格:" + a.BookPrice);

            Console.ReadKey() ; 
        }      
    }
}