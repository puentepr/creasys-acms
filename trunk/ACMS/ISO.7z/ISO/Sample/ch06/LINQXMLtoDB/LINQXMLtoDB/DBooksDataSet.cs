﻿namespace LINQXMLtoDB {
    
    
    public partial class DBooksDataSet {
    }
}
