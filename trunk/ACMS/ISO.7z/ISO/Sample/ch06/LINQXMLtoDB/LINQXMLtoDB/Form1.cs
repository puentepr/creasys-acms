﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Linq;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;  

namespace LINQXMLtoDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void DBXMLButton_Click(object sender, EventArgs e)
        {
            try
            {
                XElement xe = XElement.Parse(XMLRichTextBox.Text);
                foreach (var v in xe.Elements("Book"))
                {
                    InsertIntoBook(
                        v.Element("BookTitle").Value,
                        v.Element("BookAuthor").Value,
                        v.Element("BookISBN").Value)   ; 
                }
                MessageBox.Show("已經XML文件儲存至資料庫…");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void InsertIntoBook(
            string bookTitle  , 
            string bookAuthor ,
            string bookISBN)
        {
            BookDataClassesDataContext bookDC =
                new BookDataClassesDataContext(System.Environment.CurrentDirectory + "\\DBooks.mdf");
            Book book = new Book();
            book.BookTitle = bookTitle;
            book.BookISBN = bookISBN;
            book.BookAuthor = bookAuthor;

            Table<Book> sBook = bookDC.GetTable<Book>();
            sBook.InsertOnSubmit(book);           
            bookDC.SubmitChanges();
        }
    }
}
