﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UListG
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>
            {
                "Mon", "Tue", "Wed", 
                      "Thu", "Fri", "Sat", "Sun"
            };

            string outputString = "";
            foreach (String str in list)
            {
                outputString += str + ",";
            }
            Console.WriteLine(outputString);

            List<int> listint = new List<int>
            {
               1,2,3,4,5,6,7    
            };
            foreach (int str in listint)
            {
                outputString += str + ",";
            }            
            Console.WriteLine(outputString);
            Console.ReadKey();
        }
    }
}
