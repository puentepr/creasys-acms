﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ULambdaExe
{
    class Program
    {
        delegate int  DoMath(int px , int py );
        static void Main(string[] args)
        {
            int  result = 0;
            DoMath doMath =
                (x, y) =>
                {
                    result = x + y;
                    return result;
                }; 
            Console.WriteLine("result變數值:"+result.ToString()  )  ;
            Console.WriteLine("doMath執行結果:" + doMath(20, 30).ToString());
            Console.WriteLine("result變數值:" + result.ToString());

            //Console.WriteLine("x 變數值:" + x.ToString());
            Console.ReadKey();

        }
    }
}
