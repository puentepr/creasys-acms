﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UDelegateMethod
{
    class Program
    {
        public delegate string helloDelegate(string pName); 
        static void Main(string[] args)
        {
            Program pg = new Program();
            helloDelegate myhelloDelegate =delegate(string pNamex)
            {
                string message = "Hello,";
                message += pNamex ;
                return message;
            };
            Console.WriteLine(myhelloDelegate("kangting"));
            Console.ReadKey();
        }
    }
}
