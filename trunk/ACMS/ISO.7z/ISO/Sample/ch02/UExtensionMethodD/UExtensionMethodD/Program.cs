﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UExtensionMethodD
{
    class Program
    {
        static void Main(string[] args)
        {
            MessageFunc messageFunc = new MessageFunc();
            //string message = messageFunc.SayHello("Tim");
            //Console.WriteLine(message);
            Console.ReadLine();
        }
    }
    public class MessageFunc
    {
        //public string SayHello(string str)
        //{
        //    string helloMessage;
        //    helloMessage = "Hello , " + str;
        //    return helloMessage;
        //}
    }
    public static class ExtensionString
    {
        public static string SayHello(this MessageFunc msgFunc, string strName)
        {
            string helloMessage;
            helloMessage = "Welcome , " + strName;
            return helloMessage;
        }
    }
    public static class ExtensionString2
    {
        public static string SayHello(this MessageFunc msgFunc, string strName)
        {
            string helloMessage;
            helloMessage = "Welcome , " + strName;
            return helloMessage;
        }
    }
}
