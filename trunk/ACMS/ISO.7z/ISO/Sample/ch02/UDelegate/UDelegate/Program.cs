﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UDelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            Program pg  =new Program()   ;
            helloDelegate myHelloDelegate = new helloDelegate(pg.ReturnMessage);
            string message  =myHelloDelegate("kangting");
            Console.WriteLine(message);
            Console.ReadKey(); 
        }
        public string ReturnMessage(string pName)
        {
            string message = "Hello,";
            message += pName;
            return message;
        }
        public delegate string helloDelegate(string pName);        
    }
}
