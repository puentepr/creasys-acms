﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList weekDayList = new ArrayList {
                      "Mon", "Tue", "Wed", 
                      "Thu", "Fri", "Sat", "Sun" };

                  
            string outputString = "weekDayList內容元素:\n";

            foreach (Object str in weekDayList)
            {               
                    outputString += str + ",";
            }
            Console.Write(outputString + "\n\n");

            outputString = "weekDayList以T為字首的內容元素(透過foreach列舉):\n";
            foreach (Object  str in weekDayList)
            {
                if (str.ToString().StartsWith( "T"))
                    outputString += str+ ",";                     
            }
            Console.Write(outputString + "\n\n");

            IEnumerator enumerator = weekDayList.GetEnumerator();
            outputString = "weekDayList以T為字首的內容元素(透過IEnumerator列舉):\n";
            while (enumerator.MoveNext())
            {
                string str = enumerator.Current.ToString();
                if (str.StartsWith("T"))
                outputString += 
                    enumerator.Current.ToString() + ","; 
            }
            Console.Write(outputString);
            Console.ReadKey();
        }
    }
}
