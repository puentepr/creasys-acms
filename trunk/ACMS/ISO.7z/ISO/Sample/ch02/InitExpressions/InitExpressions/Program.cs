﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

    namespace InitExpressions
    {
        class Program
        {
            static void Main(string[] args)
            {
                ObjectInitEx objInitx1 = new ObjectInitEx("www.kangting.tw");
                objInitx1.paraOtherString = "www.delightpress.com.tw";
                Console.WriteLine(
                    "paraString:"+objInitx1.paraString + "\n" +
                    "paraOtherString:" + objInitx1.paraOtherString + "\n");

                ObjectInitEx objInitx2 =
                    new ObjectInitEx("kangting.tw")
                    {
                        paraOtherString = "delightpress.com.tw"
                    };
               
                Console.WriteLine(
                    "paraString:" + objInitx2.paraString + "\n" +
                    "paraOtherString:" + objInitx2.paraOtherString + "\n");

                Console.ReadKey();
            }
        }
        public class ObjectInitEx
        {
            public string  paraString = "";        
            public string paraOtherString = "";

            public ObjectInitEx()
            {
            }
            public ObjectInitEx( string paraStr)
            {

                this.paraString = paraStr; 
            }
        }
    }
