﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UVarObject
{
    class Program
    {
        static void Main(string[] args)
        {
            var varObject = new VarCls();
            Console.WriteLine(varObject.para1);
            Console.WriteLine(varObject.para2);
            Console.Read();
        }
    }
    public class VarCls
    {        
        public string para1 = "www.kangting.tw";
        public int para2 = 123 ;

        //public int   DoSomething(int para)
        //{
        //    var xx = null  ;
        //    var yy ; 
        //    return 123;
        //}
    }
}
