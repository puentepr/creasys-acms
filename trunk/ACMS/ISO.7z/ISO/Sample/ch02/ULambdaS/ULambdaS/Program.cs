﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ULambdaS
{
    class Program
    {
        delegate int  DoAdd(int px,int py );
        static void Main(string[] args)
        {
            Program pg = new Program();
            DoAdd myDoAdd =
                (int x, int y) => 
                { 
                    int result  = x + y;
                    return result; 
                };
            int resultAdd = myDoAdd(20, 30);
            Console.WriteLine("20+30="+resultAdd);
            Console.ReadKey();
        }
    }
}
