﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EnumG
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>
            {
                "Mon", "Tue", "Wed", 
                      "Thu", "Fri", "Sat", "Sun"
            };

            string outputString = "";
            IEnumerator<string> enumerator = list.GetEnumerator(); 

            while(enumerator.MoveNext())     
            {
                string str = enumerator.Current;
                outputString += str + ",";
            }            
            Console.WriteLine(outputString);

            List<int> listint = new List<int>
            {
               1,2,3,4,5,6,7    
            };

            IEnumerator<int> enumeratorint = listint.GetEnumerator();
            while (enumeratorint.MoveNext())     
            {
                string str = enumeratorint.Current.ToString()  ;
                outputString += str + ",";
            }
            Console.WriteLine(outputString);
            Console.ReadKey();
        }
    }
}
