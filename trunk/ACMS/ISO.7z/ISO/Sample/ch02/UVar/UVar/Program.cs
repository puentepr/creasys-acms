﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UVar
{
    class Program
    {
        static void Main(string[] args)
        {
            var v = 100;
            Object o = 100;
            int i = v ;
            int j = (int)o;
           // int j = o;
        }
    }
}
