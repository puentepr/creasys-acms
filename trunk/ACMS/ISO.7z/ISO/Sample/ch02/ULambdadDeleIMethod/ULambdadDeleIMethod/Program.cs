﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ULambdadDeleIMethod
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Program pg = new Program();
            //Func<string, string> myHelloDelegate =
            //    delegate(string pName)
            //    {
            //        string message = "Hello,";
            //        message += pName;
            //        return message;
            //    };

            Func<string, string> myHelloDelegate =
                pName => 
                {
                    string message = "Hello,";
                    message += pName;
                    return message;
                };

            string helloMessage = myHelloDelegate("kangting");
            Console.WriteLine(helloMessage);
            Console.ReadKey();
        }
        //public string ReturnMessage(string pName)
        //{
        //    string message = "Hello,";
        //    message += pName;
        //    return message;
        //}

    }
}
