﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class QueryExpressionTest
{
    static void Main(string[] args)
    {
        string[] countrysQuery = { 
                "Taiwan", "China", 
                "America", "England" };
        IEnumerable<string> enumContrys =
            from contry in countrysQuery
            where contry == "Taiwan"
            select contry;

        string source = "原始字串:"  ; 
        foreach (string contry in countrysQuery)
        {
            source += contry +"," ;              
        }
        Console.WriteLine(source);
        foreach (string contry in enumContrys)
        {
            Console.WriteLine("搜尋結果:" + contry); 
        }
        Console.ReadLine(); 
    }
}