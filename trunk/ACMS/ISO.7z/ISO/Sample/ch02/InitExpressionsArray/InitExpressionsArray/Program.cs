﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InitExpressionsArray
{
    class Program
    {
        static void Main(string[] args)
        {
            var arraykangting = new[] 
            { 
                "www","kangting","tw"
            };
            Console.WriteLine("--arraykangting--");
            foreach (var strArr in arraykangting)
            {
                Console.WriteLine(strArr);                
            }
            var arraystrs = new[] 
            { 
                new 
                {
                    site1="www.kangting.tw" ,
                    site2=new []{"blog","port"}  
                },
                new 
                {
                    site1="www.microsoft.com" ,
                    site2=new []{"msdn","msn"}  
                }            
            };
            Console.WriteLine("\n--arraystrs--");
            foreach (var strArr in arraystrs)
            {
                Console.WriteLine("site1：" + strArr.site1.ToString());
                string[] strArrs = (string[])strArr.site2;
                Console.Write("site2：");
                foreach (var str in strArrs)
                    Console.Write(str + ",");
                Console.WriteLine("");
            }
           
            var arrObjectInitEx = new[] 
            {
                new ObjectInitEx {paraString="yahoo",paraOtherString="google"}  ,
                new ObjectInitEx {paraString="amazon",paraOtherString="eBay"}                  
            };
            Console.WriteLine("\n--arrObjectInitEx--");
            foreach (var strArr in arrObjectInitEx)
            {
                Console.WriteLine("paraString：" + strArr.paraString);
                Console.WriteLine("paraOtherString：" + strArr.paraOtherString);                
            }
            Console.ReadKey();
        }
    }
    public class ObjectInitEx
    {
        public string paraString = "";
        public string paraOtherString = "";
    }
}
