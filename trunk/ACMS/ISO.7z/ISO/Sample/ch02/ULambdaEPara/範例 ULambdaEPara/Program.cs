﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ULambdaEPara
{
    class Program
    {
        delegate void showMessage();
        static void Main(string[] args)
        {
            showMessage showMessage =
                () =>
                {
                    Console.WriteLine("Hello !!");
                };
            showMessage();
            Console.ReadKey();
        }
    }
}
