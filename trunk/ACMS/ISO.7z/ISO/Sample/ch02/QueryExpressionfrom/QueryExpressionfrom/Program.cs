﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QueryExpressionfrom
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numberQuery = { 
                123,456,789,100,365,7,24 };
            IEnumerable<int> enumNumbers =
                from number in numberQuery
                select number;

            string source = "原始數字:";
            foreach (int number in numberQuery)
            {
                source += number + ",";
            }
            Console.WriteLine(source);

            string result = "搜尋結果:" ;

            foreach (int number in enumNumbers)
            {
                result += number + ",";                
            }
            Console.WriteLine( result);
            Console.ReadLine(); 
        }
    }
}
