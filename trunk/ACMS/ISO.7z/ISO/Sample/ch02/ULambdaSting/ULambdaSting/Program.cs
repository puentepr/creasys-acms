﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ULambdaSting
{
    class Program
    {
        delegate string DoAdd(string str1);
        static void Main(string[] args)
        {
            DoAdd myDoAdd =
                x => "www."+x+".tw" ;           
            Console.WriteLine(myDoAdd("kangting" ));
            Console.ReadKey();
        }           
    }
}
