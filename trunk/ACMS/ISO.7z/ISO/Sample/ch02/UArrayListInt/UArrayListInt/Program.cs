﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UArrayListInt
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList numberValues = new ArrayList {
                        1,2,3,4,5,6,7 };

            string outputString = "ArrayList內容元素的總合:";
            int total = 0;
            foreach (int numberValue in numberValues)
            {
                total += numberValue;
            }            
            Console.Write(outputString + total + "\n\n");

            outputString = "ArrayList內容元素的總合:";           
            foreach (int   intValue  in numberValues)
            {
                outputString += intValue;
            }
            Console.Write(outputString + total + "\n\n");
            Console.ReadKey();
        }
    }
}
