﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ULambdasp
{
    class Program
    {
        delegate int DoAdd(int px);
        static void Main(string[] args)
        {
            DoAdd myDoAdd =
                x =>
                {
                    int result = 0;
                    result = x * 2;
                    return result; 
                };
            int addValue  = myDoAdd(39)   ;
            Console.WriteLine("39*2=" + addValue.ToString() );           
            Console.ReadKey();
        }
    }
}
