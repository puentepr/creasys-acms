﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UExtensionMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            string strName = "Tim";
            string message = strName.SayHello();
            Console.WriteLine(message);
            Console.ReadKey();
        }
    }
    public static class ExtensionString
    {
        public static string SayHello(this string str)
        {
            string helloMessage;
            helloMessage = "Hello , " + str;
            return helloMessage;
        }
    }
}
