﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ULambdaBool
{
    class Program
    {
        delegate bool DoAdd(int px);
        static void Main(string[] args)
        {
            DoAdd myDoAdd =
                x => x % 2 == 0;

            if (myDoAdd(39))
                Console.WriteLine("39是偶數…");
            else
                Console.WriteLine("39是奇數…");
            Console.ReadKey();
        }

    }
}
