﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InitExpressionsProj
{
    class Program
    {
        static void Main(string[] args)
        {
            var objInitx =
                    new ObjectInitEx
                    {
                        paraString = "www.kangting.tw",
                        paraOtherString = "www.delightpress.com.tw"
                    };
            var objInitx2 =
                    new
                    {
                        objInitx.paraString,
                        objInitx.paraOtherString
                    };
            var objInitx3 =
                    new
                    {
                        para1 = "xxxx",
                        para2 = "yyyy",
                        para3 = 123
                    };
            var objInitx4=
                            new
                            {
                                objInitx.paraString,
                                objInitx3.para3
                            };
            Console.WriteLine(
                "objInitx2.paraOtherString:" + objInitx2.paraOtherString + "\n" +
                "objInitx4.paraString:" + objInitx4.paraString + "\n" +
                "objInitx4.para3:" + objInitx4.para3 + "\n"
            );
            Console.ReadKey();
        }
    }
    public class ObjectInitEx
    {
        public string paraString = "";
        public string paraOtherString = "";
    }
}
