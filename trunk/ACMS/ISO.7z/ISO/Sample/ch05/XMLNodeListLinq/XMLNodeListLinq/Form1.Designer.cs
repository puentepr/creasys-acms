﻿namespace XMLNodeListLinq
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.XMLRichTextBox = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LoadXmlFileButton = new System.Windows.Forms.Button();
            this.FileTextBox = new System.Windows.Forms.TextBox();
            this.FileTextButton = new System.Windows.Forms.Button();
            this.XMLOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.FilterTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // XMLRichTextBox
            // 
            this.XMLRichTextBox.Location = new System.Drawing.Point(92, 66);
            this.XMLRichTextBox.Name = "XMLRichTextBox";
            this.XMLRichTextBox.Size = new System.Drawing.Size(548, 210);
            this.XMLRichTextBox.TabIndex = 13;
            this.XMLRichTextBox.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(13, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 16);
            this.label1.TabIndex = 12;
            this.label1.Text = "XML檔案";
            // 
            // LoadXmlFileButton
            // 
            this.LoadXmlFileButton.Location = new System.Drawing.Point(468, 37);
            this.LoadXmlFileButton.Name = "LoadXmlFileButton";
            this.LoadXmlFileButton.Size = new System.Drawing.Size(123, 23);
            this.LoadXmlFileButton.TabIndex = 11;
            this.LoadXmlFileButton.Text = "載入XML檔案";
            this.LoadXmlFileButton.UseVisualStyleBackColor = true;
            this.LoadXmlFileButton.Click += new System.EventHandler(this.LoadXmlFileButton_Click);
            // 
            // FileTextBox
            // 
            this.FileTextBox.Location = new System.Drawing.Point(92, 10);
            this.FileTextBox.Name = "FileTextBox";
            this.FileTextBox.Size = new System.Drawing.Size(370, 22);
            this.FileTextBox.TabIndex = 10;
            // 
            // FileTextButton
            // 
            this.FileTextButton.Location = new System.Drawing.Point(468, 8);
            this.FileTextButton.Name = "FileTextButton";
            this.FileTextButton.Size = new System.Drawing.Size(43, 23);
            this.FileTextButton.TabIndex = 9;
            this.FileTextButton.Text = "…";
            this.FileTextButton.UseVisualStyleBackColor = true;
            this.FileTextButton.Click += new System.EventHandler(this.FileTextButton_Click);
            // 
            // XMLOpenFileDialog
            // 
            this.XMLOpenFileDialog.FileName = "openFileDialog1";
            // 
            // FilterTextBox
            // 
            this.FilterTextBox.Location = new System.Drawing.Point(92, 38);
            this.FilterTextBox.Name = "FilterTextBox";
            this.FilterTextBox.Size = new System.Drawing.Size(370, 22);
            this.FilterTextBox.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(30, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 16);
            this.label2.TabIndex = 15;
            this.label2.Text = "條件值";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 288);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FilterTextBox);
            this.Controls.Add(this.XMLRichTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LoadXmlFileButton);
            this.Controls.Add(this.FileTextBox);
            this.Controls.Add(this.FileTextButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox XMLRichTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button LoadXmlFileButton;
        private System.Windows.Forms.TextBox FileTextBox;
        private System.Windows.Forms.Button FileTextButton;
        private System.Windows.Forms.OpenFileDialog XMLOpenFileDialog;
        private System.Windows.Forms.TextBox FilterTextBox;
        private System.Windows.Forms.Label label2;
    }
}

