﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace XMLElementAtt
{
    public partial class Form1 : Form
    {
        XElement xEleBook = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            xEleBook = new XElement("Book",
                            new XElement(
                                "BookTitle",
                                "Microsoft SQL Server 2005設計商業智慧解決方案",
                                new XAttribute("Type", "Chineses")),
                            new XElement(
                                "BookTitle",
                                "Microsoft SQL Server 2005 Business Intelligence Implementation and Maintenance",
                                new XAttribute("Type", "English"))
                      );
            XMLRichTextBox.Text = xEleBook.ToString();
        }

        private void AttButton_Click(object sender, EventArgs e)
        {

            IEnumerable<XElement> xEleBooks = xEleBook.Elements("BookTitle");
            string attString = ""; 
            foreach(XElement xEle in xEleBooks)
            {
                IEnumerable<XAttribute> enumAtt = xEle.Attributes();
                IEnumerable<XAttribute> enumAttList =
                    from att in enumAtt
                    select att;

                foreach (XAttribute xAtt in enumAttList)
                    attString += xAtt.Name + "/" + xAtt.Value+ "\n"; 
            }
            AttRichTextBox.Text = attString;
        }
        
    }
}
