﻿namespace XMLElementAtt
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.XMLRichTextBox = new System.Windows.Forms.RichTextBox();
            this.AttRichTextBox = new System.Windows.Forms.RichTextBox();
            this.AttButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // XMLRichTextBox
            // 
            this.XMLRichTextBox.Location = new System.Drawing.Point(12, 100);
            this.XMLRichTextBox.Name = "XMLRichTextBox";
            this.XMLRichTextBox.Size = new System.Drawing.Size(622, 146);
            this.XMLRichTextBox.TabIndex = 7;
            this.XMLRichTextBox.Text = "";
            // 
            // AttRichTextBox
            // 
            this.AttRichTextBox.Location = new System.Drawing.Point(12, 6);
            this.AttRichTextBox.Name = "AttRichTextBox";
            this.AttRichTextBox.Size = new System.Drawing.Size(344, 88);
            this.AttRichTextBox.TabIndex = 8;
            this.AttRichTextBox.Text = "";
            // 
            // AttButton
            // 
            this.AttButton.Location = new System.Drawing.Point(440, 12);
            this.AttButton.Name = "AttButton";
            this.AttButton.Size = new System.Drawing.Size(125, 23);
            this.AttButton.TabIndex = 9;
            this.AttButton.Text = "取出屬性";
            this.AttButton.UseVisualStyleBackColor = true;
            this.AttButton.Click += new System.EventHandler(this.AttButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 257);
            this.Controls.Add(this.AttButton);
            this.Controls.Add(this.AttRichTextBox);
            this.Controls.Add(this.XMLRichTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox XMLRichTextBox;
        private System.Windows.Forms.RichTextBox AttRichTextBox;
        private System.Windows.Forms.Button AttButton;
    }
}

