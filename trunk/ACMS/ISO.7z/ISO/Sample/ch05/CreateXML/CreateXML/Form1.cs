﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CreateXML
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            XNamespace xnm = "http://kangting.tw";
            XName xn = xnm + "Books";

        XDocument xDoc = new XDocument(
                new XDeclaration("1.0", "UTF-8", "yes"),
                new XProcessingInstruction("LINQ", "LINQ入門教學"),
                new XComment( "悅知文化嚴選圖書"),
                new XElement(xn, 
                    new XElement(xnm+"Book",
                        new XComment("史上最強Photoshop技術圖書"),
                        new XElement(xnm + "BookTitle", "Photoshop CS3 影像創造力╳基礎講堂"),
                        new XElement(xnm + "BookISBN", "978-986-6761-21-8")),
                    new XElement(xnm + "Book",
                        new XComment("MAYA聖典，不可不看"),
                        new XElement(xnm + "BookTitle", "MAYA 火星講堂"),
                        new XElement(xnm + "BookISBN", "978-986-6761-19-5")),
                    new XElement(xnm + "Book",
                        new XComment("Photoshop超可愛手繪技巧完全披露"),
                        new XElement(xnm + "BookTitle", "手繪魅力100% ♥ Photoshop+Wacom ♥ "),
                        new XElement(xnm + "BookISBN", "978-986-6761-17-1"))));

            string str = xDoc.Declaration + "\n";
            str += xDoc; 
            
            XMLRichTextBox.Text = str;
 
        }
    }
}
