﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq; 

namespace XMLElementSetValue
{
    public partial class Form1 : Form
    {
        XElement xEleBook = null  ; 
        public Form1()
        {
            InitializeComponent();
        }
        private void SetElement()
        {
            xEleBook = new XElement(
                new XElement("Books",
                    new XElement("Book",
                        new XElement("BookTitle", "Photoshop CS3 影像創造力╳基礎講堂"),
                        new XElement("BookISBN", "978-986-6761-21-8")),
                    new XElement("Book",
                        new XElement("BookTitle", "MAYA 火星講堂"),
                        new XElement("BookISBN", "978-986-6761-19-5")),
                    new XElement("Book",
                        new XElement("BookTitle", "手繪魅力100% ♥ Photoshop+Wacom ♥ "),
                        new XElement("BookISBN", "978-986-6761-17-1")))
             );

            XMLRichTextBox.Text = xEleBook.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SetElement();
        }
        private void SetValueButton_Click(object sender, EventArgs e)
        {
            string xmlEleCurrent = CurrentTextBox.Text;
            string xmlSet = SetTextBox.Text;
            
            string xmlValue = SetValueTextBox.Text;
            XElement xe = xEleBook.Element(xmlEleCurrent);
            if(xe==null)
            {
                MessageBox.Show("查無相關元素…") ;
                return; 
            }
            if (xmlValue.Length == 0)
                xmlValue = null; 
            xe.SetElementValue(xmlSet, xmlValue);
            XMLRichTextBox.Text = xEleBook.ToString();
        }


    }
}
