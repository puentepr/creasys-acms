﻿namespace XMLElementSetValue
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.SetValueButton = new System.Windows.Forms.Button();
            this.SetTextBox = new System.Windows.Forms.TextBox();
            this.SetValueTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.XMLRichTextBox = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CurrentTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // SetValueButton
            // 
            this.SetValueButton.Location = new System.Drawing.Point(598, 43);
            this.SetValueButton.Name = "SetValueButton";
            this.SetValueButton.Size = new System.Drawing.Size(94, 33);
            this.SetValueButton.TabIndex = 0;
            this.SetValueButton.Text = "設定元素內容";
            this.SetValueButton.UseVisualStyleBackColor = true;
            this.SetValueButton.Click += new System.EventHandler(this.SetValueButton_Click);
            // 
            // SetTextBox
            // 
            this.SetTextBox.Location = new System.Drawing.Point(99, 47);
            this.SetTextBox.Name = "SetTextBox";
            this.SetTextBox.Size = new System.Drawing.Size(86, 22);
            this.SetTextBox.TabIndex = 9;
            // 
            // SetValueTextBox
            // 
            this.SetValueTextBox.Location = new System.Drawing.Point(191, 47);
            this.SetValueTextBox.Name = "SetValueTextBox";
            this.SetValueTextBox.Size = new System.Drawing.Size(399, 22);
            this.SetValueTextBox.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(21, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "設定元素";
            // 
            // XMLRichTextBox
            // 
            this.XMLRichTextBox.Location = new System.Drawing.Point(15, 82);
            this.XMLRichTextBox.Name = "XMLRichTextBox";
            this.XMLRichTextBox.Size = new System.Drawing.Size(677, 302);
            this.XMLRichTextBox.TabIndex = 13;
            this.XMLRichTextBox.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(21, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "元素名稱";
            // 
            // CurrentTextBox
            // 
            this.CurrentTextBox.Location = new System.Drawing.Point(99, 20);
            this.CurrentTextBox.Name = "CurrentTextBox";
            this.CurrentTextBox.Size = new System.Drawing.Size(86, 22);
            this.CurrentTextBox.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 410);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CurrentTextBox);
            this.Controls.Add(this.XMLRichTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SetValueTextBox);
            this.Controls.Add(this.SetTextBox);
            this.Controls.Add(this.SetValueButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SetValueButton;
        private System.Windows.Forms.TextBox SetTextBox;
        private System.Windows.Forms.TextBox SetValueTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox XMLRichTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox CurrentTextBox;
    }
}

