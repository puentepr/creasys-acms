﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml; 

namespace XMLMethodExElements
{
    public partial class Form1 : Form
    {
        XElement xEle = null;
        public Form1()
        {
            InitializeComponent();
        }
        private void FileTextButton_Click(object sender, EventArgs e)
        {
            DialogResult dr = XMLOpenFileDialog.ShowDialog();
            if (dr == DialogResult.OK)
                FileTextBox.Text = XMLOpenFileDialog.FileName;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void LoadXmlFileButton_Click(object sender, EventArgs e)
        {
            string fileName = FileTextBox.Text;

            if (fileName.Length > 0)
            {
                try
                {
                    xEle = XElement.Load(fileName);
                    MessageBox.Show("XML載入完成…");
                }
                catch (XmlException xmlEx)
                {
                    MessageBox.Show(xmlEx.Message);
                    return;
                }
            }
            else
            {
                MessageBox.Show("請指定所要載入的檔案來源…");
                return;
            }
        }


        private void SearchButton_Click(object sender, EventArgs e)
        {
            if (xEle == null)
            {
                MessageBox.Show("請先載入XML檔案…");
                return;
            }
            string str = "";
                IEnumerable<XElement> xenum =
                    from xe in xEle.Elements().Elements("Title")
                    select xe;

            foreach (XElement x in xenum)
                str += x+"\n" ;
            XMLRichTextBox.Text = str;             

        }
    }
}
