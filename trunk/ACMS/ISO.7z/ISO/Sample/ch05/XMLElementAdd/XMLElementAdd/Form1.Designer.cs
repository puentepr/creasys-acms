﻿namespace XMLElementAdd
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.XMLRichTextBox = new System.Windows.Forms.RichTextBox();
            this.AddButton = new System.Windows.Forms.Button();
            this.AddRadioButton = new System.Windows.Forms.RadioButton();
            this.AddFirstRadioButton = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // XMLRichTextBox
            // 
            this.XMLRichTextBox.Location = new System.Drawing.Point(13, 70);
            this.XMLRichTextBox.Name = "XMLRichTextBox";
            this.XMLRichTextBox.Size = new System.Drawing.Size(677, 387);
            this.XMLRichTextBox.TabIndex = 0;
            this.XMLRichTextBox.Text = "";
            // 
            // AddButton
            // 
            this.AddButton.Location = new System.Drawing.Point(218, 30);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(215, 23);
            this.AddButton.TabIndex = 1;
            this.AddButton.Text = "顯示新元素加入結果";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // AddRadioButton
            // 
            this.AddRadioButton.AutoSize = true;
            this.AddRadioButton.Location = new System.Drawing.Point(46, 14);
            this.AddRadioButton.Name = "AddRadioButton";
            this.AddRadioButton.Size = new System.Drawing.Size(71, 16);
            this.AddRadioButton.TabIndex = 2;
            this.AddRadioButton.Text = "加入元素";
            this.AddRadioButton.UseVisualStyleBackColor = true;
            // 
            // AddFirstRadioButton
            // 
            this.AddFirstRadioButton.AutoSize = true;
            this.AddFirstRadioButton.Location = new System.Drawing.Point(46, 37);
            this.AddFirstRadioButton.Name = "AddFirstRadioButton";
            this.AddFirstRadioButton.Size = new System.Drawing.Size(107, 16);
            this.AddFirstRadioButton.TabIndex = 3;
            this.AddFirstRadioButton.TabStop = true;
            this.AddFirstRadioButton.Text = "加入第一個元素";
            this.AddFirstRadioButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 469);
            this.Controls.Add(this.AddFirstRadioButton);
            this.Controls.Add(this.AddRadioButton);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.XMLRichTextBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox XMLRichTextBox;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.RadioButton AddRadioButton;
        private System.Windows.Forms.RadioButton AddFirstRadioButton;
    }
}

