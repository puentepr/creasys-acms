﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml;

namespace XMLElememtList
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void LoadXmlFileButton_Click(object sender, EventArgs e)
        {
            string fileName = FileTextBox.Text;
            XElement xEle = null;

            if (fileName.Length > 0)
            {
                try
                {
                    xEle = XElement.Load(fileName);
                }
                catch (XmlException xmlEx)
                {
                    MessageBox.Show(xmlEx.Message);
                    return;
                }
            }
            else
            {
                MessageBox.Show("請指定所要載入的檔案來源…");
                return;
            }
            string xmlContent = " --- ";
            //IEnumerable<XElement > enumXMLs = xEle.Elements( );
            //var  enumXML = 
            //    from xmlEle in enumXMLs
            //    where  CheckElement( xmlEle)    
            //    select xmlEle ;

            IEnumerable<XElement> enumXML  = null   ;
            if (FilterTextBox.Text == "")
                enumXML = xEle.Elements();
            else
                enumXML = xEle.Elements(FilterTextBox.Text);
            if (enumXML != null)
            {
                xmlContent = "";
                foreach (string v in enumXML)
                {
                    xmlContent += v + "\n";
                }
            }
            else
            {
                MessageBox.Show("找不到任何符合條件的元素…");
            }
            XMLRichTextBox.Text = xmlContent;

        }
        private void FileTextButton_Click(object sender, EventArgs e)
        {
            DialogResult dr = XMLOpenFileDialog.ShowDialog();
            if (dr == DialogResult.OK)
                FileTextBox.Text = XMLOpenFileDialog.FileName;

        }
        private bool CheckElement(XElement xEle)
        {
            if (FilterTextBox.Text.Length == 0)
                return true;
            bool checkResult = false;
            XName xName = FilterTextBox.Text;
            checkResult = xEle.Name == xName;
            return checkResult;
        }
    }
}
