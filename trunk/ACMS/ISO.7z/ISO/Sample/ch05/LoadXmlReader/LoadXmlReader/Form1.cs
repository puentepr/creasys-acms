﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml;
using  System.IO ; 

namespace LoadXmlReader
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void LoadXMLButton_Click(object sender, EventArgs e)
        {
            try
            {
                TextReader tr = new StringReader(XMLRichTextBox.Text);
                XElement xEle = XElement.Load(tr);
                MessageBox.Show("XML載入完成…");
            }
            catch (XmlException xmlex)
            {
                MessageBox.Show(xmlex.Message);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            XMLRichTextBox.Text =
                @"<?xml version=""1.0"" encoding=""utf-8"" ?>" + "\n" +
                    @"<Books>" + "\n" +
                      @"<Book>" + "\n" +
                        @"<ISBN>978-986-6761-23-2</ISBN>" + "\n" +
                        @"<Title language= ""Chinese"" >Microsoft SQL Server 2005設計商業智慧解決方案</Title>" + "\n" +
                        @"<Title language= ""Chinese"" > Microsoft SQL Server 2005 Business Intelligence Implementation and Maintenance </Title> " + "\n" +
                    @"<Author type=""auth""> Erik Veerman </Author>" + "\n" +
                    @"<Author type=""trans"">尹相志</Author>" + "\n" +
                    @"<Pages>608 </Pages>" + "\n" +
                    @"<Price>" + "\n" +
                      @"<OPrice>780</OPrice>" + "\n" +
                      @"<Sale>624</Sale>" + "\n" +
                    @"</Price>" + "\n" +
                    @"<Category>" + "\n" +
                       @"<Main>資料庫</Main>" + "\n" +
                       @"<Sub>專業認證</Sub>" + "\n" +
                    @"</Category>" + "\n" +
                       @"</Book>" + "\n" +
                    @"</Books>";

        }
    }
}
