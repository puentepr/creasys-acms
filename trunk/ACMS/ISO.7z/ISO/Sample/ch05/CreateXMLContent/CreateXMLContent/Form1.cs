﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml; 

namespace CreateXMLContent
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            XDocument xDoc = new XDocument(
                new XElement("Books",
                    new XElement("Book",
                        new XElement("BookTitle","Photoshop CS3 影像創造力╳基礎講堂"),
                        new XElement("BookISBN", "978-986-6761-21-8")),
                    new XElement("Book",
                        new XElement("BookTitle", "MAYA 火星講堂"),
                        new XElement("BookISBN", "978-986-6761-19-5")),
                    new XElement("Book",
                        new XElement("BookTitle", "手繪魅力100% ♥ Photoshop+Wacom ♥ "),
                        new XElement("BookISBN", "978-986-6761-17-1")))
                 );
            XMLRichTextBox.Text = xDoc.ToString()      ; 

             
                
        }
    }
}
