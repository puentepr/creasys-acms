﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml;

namespace XMLNodeList
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LoadXmlFileButton_Click(object sender, EventArgs e)
        {
            string fileName = FileTextBox.Text;
            XElement xEle = null;

            if (fileName.Length > 0)
            {
                try
                {
                    xEle = XElement.Load(fileName);
                    MessageBox.Show("XML載入完成…");
                }
                catch (XmlException xmlEx)
                {
                    MessageBox.Show(xmlEx.Message);
                    return;
                }
            }
            else
            {
                MessageBox.Show("請指定所要載入的檔案來源…");
                return;
            }
            string xmlContent = "";
            foreach(XNode  v in xEle.Nodes())
            {
                xmlContent += v.ToString()  + "\n"; 
            }
            XMLRichTextBox.Text = xmlContent;
 
        }
        private void FileTextButton_Click(object sender, EventArgs e)
        {
            DialogResult dr = XMLOpenFileDialog.ShowDialog();
            if (dr == DialogResult.OK)
                FileTextBox.Text = XMLOpenFileDialog.FileName;  
            
        }
    }
}
