﻿namespace XMLNodeList
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.LoadXmlFileButton = new System.Windows.Forms.Button();
            this.FileTextBox = new System.Windows.Forms.TextBox();
            this.FileTextButton = new System.Windows.Forms.Button();
            this.XMLRichTextBox = new System.Windows.Forms.RichTextBox();
            this.XMLOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(26, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "XML檔案";
            // 
            // LoadXmlFileButton
            // 
            this.LoadXmlFileButton.Location = new System.Drawing.Point(530, 10);
            this.LoadXmlFileButton.Name = "LoadXmlFileButton";
            this.LoadXmlFileButton.Size = new System.Drawing.Size(123, 23);
            this.LoadXmlFileButton.TabIndex = 6;
            this.LoadXmlFileButton.Text = "載入XML檔案";
            this.LoadXmlFileButton.UseVisualStyleBackColor = true;
            this.LoadXmlFileButton.Click += new System.EventHandler(this.LoadXmlFileButton_Click);
            // 
            // FileTextBox
            // 
            this.FileTextBox.Location = new System.Drawing.Point(105, 12);
            this.FileTextBox.Name = "FileTextBox";
            this.FileTextBox.Size = new System.Drawing.Size(370, 22);
            this.FileTextBox.TabIndex = 5;
            // 
            // FileTextButton
            // 
            this.FileTextButton.Location = new System.Drawing.Point(481, 10);
            this.FileTextButton.Name = "FileTextButton";
            this.FileTextButton.Size = new System.Drawing.Size(43, 23);
            this.FileTextButton.TabIndex = 4;
            this.FileTextButton.Text = "…";
            this.FileTextButton.UseVisualStyleBackColor = true;
            this.FileTextButton.Click += new System.EventHandler(this.FileTextButton_Click);
            // 
            // XMLRichTextBox
            // 
            this.XMLRichTextBox.Location = new System.Drawing.Point(105, 40);
            this.XMLRichTextBox.Name = "XMLRichTextBox";
            this.XMLRichTextBox.Size = new System.Drawing.Size(548, 331);
            this.XMLRichTextBox.TabIndex = 8;
            this.XMLRichTextBox.Text = "";
            // 
            // XMLOpenFileDialog
            // 
            this.XMLOpenFileDialog.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 386);
            this.Controls.Add(this.XMLRichTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LoadXmlFileButton);
            this.Controls.Add(this.FileTextBox);
            this.Controls.Add(this.FileTextButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button LoadXmlFileButton;
        private System.Windows.Forms.TextBox FileTextBox;
        private System.Windows.Forms.Button FileTextButton;
        private System.Windows.Forms.RichTextBox XMLRichTextBox;
        private System.Windows.Forms.OpenFileDialog XMLOpenFileDialog;
    }
}

