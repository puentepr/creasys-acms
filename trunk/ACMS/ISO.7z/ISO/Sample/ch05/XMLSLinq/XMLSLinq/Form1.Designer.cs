﻿namespace XMLSLinq
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改這個方法的內容。
        ///
        /// </summary>
        private void InitializeComponent()
        {
            this.XMLRichTextBox = new System.Windows.Forms.RichTextBox();
            this.BookRichTextBox = new System.Windows.Forms.RichTextBox();
            this.TitleRichTextBox = new System.Windows.Forms.RichTextBox();
            this.GoButton2 = new System.Windows.Forms.Button();
            this.GoButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // XMLRichTextBox
            // 
            this.XMLRichTextBox.Location = new System.Drawing.Point(12, 12);
            this.XMLRichTextBox.Name = "XMLRichTextBox";
            this.XMLRichTextBox.Size = new System.Drawing.Size(811, 233);
            this.XMLRichTextBox.TabIndex = 9;
            this.XMLRichTextBox.Text = "";
            // 
            // BookRichTextBox
            // 
            this.BookRichTextBox.Location = new System.Drawing.Point(12, 283);
            this.BookRichTextBox.Name = "BookRichTextBox";
            this.BookRichTextBox.Size = new System.Drawing.Size(811, 119);
            this.BookRichTextBox.TabIndex = 10;
            this.BookRichTextBox.Text = " ";
            // 
            // TitleRichTextBox
            // 
            this.TitleRichTextBox.Location = new System.Drawing.Point(12, 441);
            this.TitleRichTextBox.Name = "TitleRichTextBox";
            this.TitleRichTextBox.Size = new System.Drawing.Size(811, 119);
            this.TitleRichTextBox.TabIndex = 11;
            this.TitleRichTextBox.Text = " ";
            // 
            // GoButton2
            // 
            this.GoButton2.Location = new System.Drawing.Point(12, 412);
            this.GoButton2.Name = "GoButton2";
            this.GoButton2.Size = new System.Drawing.Size(170, 23);
            this.GoButton2.TabIndex = 12;
            this.GoButton2.Text = "列舉BookTitle元素";
            this.GoButton2.UseVisualStyleBackColor = true;
            this.GoButton2.Click += new System.EventHandler(this.GoButton2_Click);
            // 
            // GoButton
            // 
            this.GoButton.Location = new System.Drawing.Point(12, 254);
            this.GoButton.Name = "GoButton";
            this.GoButton.Size = new System.Drawing.Size(170, 23);
            this.GoButton.TabIndex = 0;
            this.GoButton.Text = "列舉Book元素";
            this.GoButton.UseVisualStyleBackColor = true;
            this.GoButton.Click += new System.EventHandler(this.GoButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(835, 572);
            this.Controls.Add(this.GoButton2);
            this.Controls.Add(this.TitleRichTextBox);
            this.Controls.Add(this.BookRichTextBox);
            this.Controls.Add(this.XMLRichTextBox);
            this.Controls.Add(this.GoButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox XMLRichTextBox;
        private System.Windows.Forms.RichTextBox BookRichTextBox;
        private System.Windows.Forms.RichTextBox TitleRichTextBox;
        private System.Windows.Forms.Button GoButton2;
        private System.Windows.Forms.Button GoButton;
    }
}

