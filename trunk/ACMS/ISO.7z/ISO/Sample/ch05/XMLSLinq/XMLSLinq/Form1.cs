﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq; 

namespace XMLSLinq
{
    public partial class Form1 : Form
    {
        XElement xEleBook = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            XNamespace xns = "http://kangting.tw";
            xEleBook = new XElement(
                     new XElement(xns + "Books",
                        new XElement(xns + "Book",
                            new XElement(
                                "BookTitle",
                                "Microsoft SQL Server 2005設計商業智慧解決方案",
                                new XAttribute("Type", "Chineses")),
                            new XElement(
                                "BookTitle",
                                "Microsoft SQL Server 2005 Business Intelligence Implementation and Maintenance",
                                new XAttribute("Type", "English"))),
                        new XElement(xns + "Book",
                            new XElement(
                                "BookTitle",
                                "使用Microsoft.NET Framework設計及開發Web應用程式",
                                new XAttribute("Type", "Chineses")),
                            new XElement(
                                "BookTitle",
                                "Designing and Developing Web-Based Application Using the Microsoft .NET Framework",
                                new XAttribute("Type", "English"))),
                        new XElement(xns + "Book",
                            new XElement(
                                "BookTitle",
                                "Microsoft SQL Server 2005 設計資料庫伺服器基礎架構",
                                new XAttribute("Type", "Chineses")),
                            new XElement(
                                "BookTitle",
                                "Designing a Database Server Infrastructure Using Microsoft SQL Server 2005",
                                new XAttribute("Type", "English")))
                      ));
            XMLRichTextBox.Text = xEleBook.ToString();          
        }

        private void GoButton_Click(object sender, EventArgs e)
        {
            string str = ""; 
            IEnumerable<XElement> xEles = xEleBook.Elements();
            IEnumerable<XElement> xEle =
                from x in xEles
                select x;
            
            foreach (XElement xe in xEle)
            {
                str += xe.ToString() + "\n";                 
            }
            BookRichTextBox.Text = str; 
        }
        private void GoButton2_Click(object sender, EventArgs e)
        {
            string str = "";
            IEnumerable<XElement> xEles = xEleBook.Elements();
            IEnumerable<XElement> xEle =
                from x in xEles
                select x;
            foreach (XElement xe in xEle)
            {
                IEnumerable<XElement> xEleTitle =
                    from xTitle in xe.Elements()    
                    select xTitle;
                foreach (XElement x in xEleTitle)
                {
                    str += x.ToString()+"\n"; 
                }                
            }
            TitleRichTextBox.Text = str; 
        }
    }
}
