﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LinqFirstE
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> weekDayList = new List<string> {
                      "Mon", "Tue", "Wed", 
                      "Thu", "Fri", "Sat", "Sun" };

            Console.WriteLine("原始陣列內容：");
            foreach (string str in weekDayList)
                Console.Write(str + ",");
            //　
            Console.WriteLine("\n" + "篩選第一個字元為T的陣列字串：");
            //IEnumerable<string>  enumWeek  =
            //    weekDayList.Where(weekDay => weekDay.StartsWith("T"));

            IEnumerable<string> enumWeek =
                from weekDay in weekDayList
                where weekDay.StartsWith("T")
                select weekDay;

            foreach (string str in enumWeek)
                Console.Write(str + ",");
            Console.ReadKey();

        }
    }
}
